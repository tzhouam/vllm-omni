from pathlib import Path
import json,shutil,time,hashlib
root=Path('C:/Users/zhout/w2/strata-omni');src=root/'runtime/e39-v6';vision=root/'runtime/vision-cuda-v3-reviewed';dst=root/'runtime/e39-v6-cuda-v3'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''): h.update(block)
 return h.hexdigest()
start=time.perf_counter();dst.mkdir(exist_ok=False)
records=json.loads((src/'members.json').read_text())['files'];expected={r['path']:r for r in records}
assert {p.relative_to(src).as_posix() for p in src.rglob('*') if p.is_file()}==set(expected)|{'members.json'}
phases=[]
for name,origin,target in [('baseline',src,dst),('cuda_binary',vision/'vision-cuda',dst/'vision-cuda'),('cuda_provenance',vision/'vision-build',dst/'cuda-vision-build')]:
 t=time.perf_counter();shutil.copytree(origin,target,dirs_exist_ok=(name=='baseline'));phases.append(dict(phase=name,seconds=time.perf_counter()-t));print(json.dumps(phases[-1]),flush=True)
for row in records:
 p=dst/row['path'];assert p.stat().st_size==row['size_bytes'] and digest(p)==row['sha256'],row['path']
assert digest(src/'members.json')==digest(dst/'members.json')
print('baseline members verified',flush=True)
b=dst/'cuda-vision-build/build.json';build=json.loads(b.read_text())
for row in build['evidence_files']: row['path']=row['path'].replace('vision-build/','cuda-vision-build/',1)
b.write_text(json.dumps(build,indent=2),encoding='utf-8')
files=[dict(path=p.relative_to(dst).as_posix(),size_bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(dst.rglob('*')) if p.is_file() and p.name!='members.json']
# Exclude only the root manifest; no nested filename is silently omitted.
assert len(files)==sum(p.is_file() for p in dst.rglob('*'))-1
(dst/'members.json').write_text(json.dumps(dict(schema='omni-strata-combined-members-v2',files=files),indent=2),encoding='utf-8')
report=dict(schema='omni-strata-cuda-runtime-staging-v1',source=str(src),source_members_sha256=digest(src/'members.json'),destination=str(dst),members_sha256=digest(dst/'members.json'),files=len(files),bytes=sum(r['size_bytes'] for r in files),phases=phases,wall_seconds=time.perf_counter()-start,baseline_files_verified=len(records),vision_build='cuda-vision-build/build.json',encoder='vision-cuda/strata-vision.exe',scope='hash-verified staged runtime; adapter full-load validation and neural run pending')
(root/'prototypes/cuda-v3-full-staging-20261021.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True)
