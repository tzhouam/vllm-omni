
#include <algorithm>
#include <vector>
#include <limits>
#include <cstdlib>
#include <stdexcept>
#include <cstdio>
#include <string>
struct ggml_cgraph{};
struct Sched{void* get(){return this;}};
struct clip_ctx{bool omni_budget_enabled=true;std::vector<int> backend_ptrs{0,1},backend_buft{0,1};Sched sched;size_t omni_gpu_weights=100,omni_host_weights=10,omni_gpu_limit=120,omni_host_limit=30;};
size_t old_sizes[2]={0,0},new_sizes[2]={20,20};int measured=0,resets=0;
size_t ggml_backend_sched_get_buffer_size(void*,int i){return old_sizes[i];}
void ggml_backend_sched_reserve_size(void*,ggml_cgraph*,size_t* sizes){++measured;sizes[0]=new_sizes[0];sizes[1]=new_sizes[1];}
bool ggml_backend_buft_is_host(int b){return b==1;}
bool ggml_backend_sched_reserve(void*,ggml_cgraph*){return true;}
void ggml_backend_sched_reset(void*){++resets;}
static size_t omni_vision_budget_env(const char * name) {
    const char * value = std::getenv(name);
    if (!value || !*value) throw std::runtime_error("missing vision tensor budget");
    size_t result = 0;
    for (const char * p = value; *p; ++p) {
        if (*p < '0' || *p > '9' || result > (std::numeric_limits<size_t>::max() - (*p - '0')) / 10)
            throw std::runtime_error("invalid vision tensor budget");
        result = result * 10 + (*p - '0');
    }
    return result;
}
static size_t omni_vision_budget_add(size_t a, size_t b) {
    if (b > std::numeric_limits<size_t>::max() - a)
        throw std::runtime_error("vision tensor accounting overflow");
    return a + b;
}
static void omni_vision_budget_require(size_t gpu, size_t host, size_t gpu_limit, size_t host_limit) {
    if (gpu > gpu_limit || host > host_limit)
        throw std::runtime_error("vision explicit tensor budget exceeded before allocation");
}
static void omni_vision_check_graph_budget(clip_ctx & ctx, ggml_cgraph * graph) {
    if (!ctx.omni_budget_enabled) return;
    std::vector<size_t> retained(ctx.backend_ptrs.size()), planned(ctx.backend_ptrs.size());
    for (size_t i = 0; i < retained.size(); ++i)
        retained[i] = ggml_backend_sched_get_buffer_size(ctx.sched.get(), ctx.backend_ptrs[i]);
    // Measurement can release undersized buffers, but does not allocate device buffers.
    ggml_backend_sched_reserve_size(ctx.sched.get(), graph, planned.data());
    size_t gpu = ctx.omni_gpu_weights, host = ctx.omni_host_weights;
    for (size_t i = 0; i < planned.size(); ++i) {
        const size_t bytes = std::max(retained[i], planned[i]);
        if (ggml_backend_buft_is_host(ctx.backend_buft[i])) host = omni_vision_budget_add(host, bytes);
        else gpu = omni_vision_budget_add(gpu, bytes);
    }
    omni_vision_budget_require(gpu, host, ctx.omni_gpu_limit, ctx.omni_host_limit);
    std::fprintf(stdout, "OMNI_VISION_MEMORY_V1 {\"schema\":\"strata-vision-memory-v1\","
        "\"scope\":\"explicit_ggml_tensor_buffers\",\"gpu_bytes\":%zu,\"host_bytes\":%zu,"
        "\"gpu_limit\":%zu,\"host_limit\":%zu,\"phase\":\"before_graph_allocation\"}\n",
        gpu, host, ctx.omni_gpu_limit, ctx.omni_host_limit);
    std::fflush(stdout);
    if (!ggml_backend_sched_reserve(ctx.sched.get(), graph))
        throw std::runtime_error("vision admitted graph reserve failed");
    ggml_backend_sched_reset(ctx.sched.get());
}


int tests=0;
void check(bool ok,const char* name){if(!ok){std::fprintf(stderr,"FAIL %s\n",name);std::exit(2);}++tests;std::printf("PASS %s\n",name);}
template<class F> bool throws(F f){try{f();return false;}catch(const std::runtime_error&){return true;}}
int main(){
 const char* key="OMNI_BUDGET_TEST";
 _putenv_s(key,"");check(throws([&]{omni_vision_budget_env(key);}),"missing");
 for(const char* v:{"-1","+1"," 2","2x","18446744073709551616"}){_putenv_s(key,v);check(throws([&]{omni_vision_budget_env(key);}),v);}
 _putenv_s(key,"0");check(omni_vision_budget_env(key)==0,"zero");
 _putenv_s(key,"18446744073709551615");check(omni_vision_budget_env(key)==std::numeric_limits<size_t>::max(),"max size");
 check(throws([]{omni_vision_budget_add(std::numeric_limits<size_t>::max(),1);}),"addition overflow");
 clip_ctx ctx;ggml_cgraph g;omni_vision_check_graph_budget(ctx,&g);check(measured==1&&resets==1,"exact both pools");
 ctx.omni_gpu_limit=119;check(throws([&]{omni_vision_check_graph_budget(ctx,&g);})&&resets==1,"gpu refusal before reset/allocation");
 ctx.omni_gpu_limit=120;ctx.omni_host_limit=29;check(throws([&]{omni_vision_check_graph_budget(ctx,&g);}),"host fallback refusal");
 ctx.omni_host_limit=30;old_sizes[0]=21;check(throws([&]{omni_vision_check_graph_budget(ctx,&g);}),"retained buffer refusal");
 old_sizes[0]=0;ctx.omni_gpu_weights=std::numeric_limits<size_t>::max();check(throws([&]{omni_vision_check_graph_budget(ctx,&g);}),"graph sum overflow");
 ctx.omni_budget_enabled=false;const int before=measured;omni_vision_check_graph_budget(ctx,&g);check(measured==before,"cpu bypass unchanged");
 std::printf("TOTAL %d\n",tests);return 0;}
