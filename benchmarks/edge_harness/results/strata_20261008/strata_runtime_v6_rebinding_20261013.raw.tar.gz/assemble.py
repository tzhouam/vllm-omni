"""Copy a new complete runtime, bind current image sources, then independently verify."""
import copy,hashlib,json,os,sys,time
from pathlib import Path
ROOT=Path('C:/Users/zhout/w2/strata-omni')
REPO=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge')
PARENT=ROOT/'runtime/e39-v5'
OUT=ROOT/'runtime/e39-v6'
RECEIPTS=ROOT/'patches/image-combined-runtime-v6-20261013'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    if os.name!='nt' or OUT.exists() or RECEIPTS.exists():raise RuntimeError('native Windows and fresh destinations required')
    raw_manifest=(PARENT/'members.json').read_bytes()
    if sha(raw_manifest)!='ff2896e1cf15277c65321796242bf4dd67986c7d6429c405043c92cdbfb1fb4a':raise ValueError('parent manifest changed')
    parent=json.loads(raw_manifest)
    RECEIPTS.mkdir();OUT.mkdir();start=time.monotonic()
    write(RECEIPTS/'start.json',{'parent_manifest_sha256':sha(raw_manifest),'status':'copying_and_verifying_parent_members','pid':os.getpid()})
    source_paths={r['path'] for r in parent['files']}
    if {str(p.relative_to(PARENT)).replace('\\','/') for p in PARENT.rglob('*') if p.is_file()} != source_paths|{'members.json'}:raise ValueError('unbound parent member')
    for index,row in enumerate(parent['files']):
        source=(PARENT/row['path']).resolve(strict=True);target=OUT/row['path']
        if not source.is_relative_to(PARENT.resolve()) or not target.resolve().is_relative_to(OUT.resolve()):raise ValueError('member escaped runtime')
        target.parent.mkdir(parents=True,exist_ok=True)
        digest=hashlib.sha256();count=0
        with source.open('rb') as inp,target.open('xb') as out:
            while chunk:=inp.read(65536):digest.update(chunk);out.write(chunk);count+=len(chunk)
        if count!=row['size_bytes'] or digest.hexdigest()!=row['sha256']:raise ValueError('parent bytes differ: '+row['path'])
        if index%5000==0:print(json.dumps({'copied_verified_members':index+1}),flush=True)
    sys.path.insert(0,str(REPO))
    from vllm_omni.engine.backends import strata,strata_vision
    sources={'adapter/omni_strata_stage.py':Path(strata.__file__),
             'adapter/strata_exec_live.py':Path(strata.__file__).with_name('strata_execution')/'strata_exec_live.py',
             'adapter/strata_vision.py':Path(strata_vision.__file__),
             'adapter/strata_multimodal.py':Path(strata.__file__).with_name('strata_multimodal.py')}
    changes={}
    for member,path in sources.items():
        data=path.read_bytes();(OUT/member).write_bytes(data);changes[member]={'source':str(path),'sha256':sha(data)}
    context=json.loads((OUT/'adapter/live-source-context.json').read_bytes())
    for row in context['modules']:row['sha256']=sha((OUT/row['member']).read_bytes())
    if (OUT/context['bootstrap_member']).read_bytes()!=strata._EXECUTION_BOOTSTRAP.encode():raise ValueError('text bootstrap unexpectedly changed')
    write(OUT/'adapter/live-source-context.json',context)
    image=copy.deepcopy(context);image['schema']='omni-strata-execution-image-source-context-v1'
    for role,module,member in [('vision','vllm_omni.engine.backends.strata_vision','adapter/strata_vision.py'),('multimodal','vllm_omni.engine.backends.strata_multimodal','adapter/strata_multimodal.py')]:
        image['modules'].append({'role':role,'module':module,'member':member,'sha256':sha((OUT/member).read_bytes())})
    bootstrap=strata_vision.bootstrap_source(strata._EXECUTION_BOOTSTRAP).encode()
    image['bootstrap_member']='adapter/strata_image_bootstrap.py';image['bootstrap_sha256']=sha(bootstrap)
    (OUT/image['bootstrap_member']).write_bytes(bootstrap)
    write(OUT/'adapter/image-source-context.json',image)
    rows=[]
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            digest=hashlib.sha256();size=0
            with path.open('rb') as stream:
                while chunk:=stream.read(65536):digest.update(chunk);size+=len(chunk)
            rows.append({'path':path.relative_to(OUT).as_posix(),'size_bytes':size,'sha256':digest.hexdigest()})
    write(OUT/'members.json',{'schema':parent['schema'],'files':rows})
    write(RECEIPTS/'assembly.json',{'status':'assembled_bytes_independent_static_verification_pending','members':len(rows),'bytes':sum(r['size_bytes'] for r in rows),'raw_manifest_sha256':sha((OUT/'members.json').read_bytes()),'changed_sources':changes,'elapsed_s':time.monotonic()-start,'native_execution':False})
    print(json.dumps({'phase':'independent_static_verification','members':len(rows)}),flush=True)
    modules=strata._load_execution_adapters(OUT,{(OUT/r['path']).resolve() for r in rows})
    identity=modules['strata_exec_runtime'].verify_combined_runtime('descriptor.json',OUT)
    descriptor=json.loads((OUT/'descriptor.json').read_bytes())
    bundle=modules['strata_exec_live']._reopen_static_bundle(OUT,descriptor,identity)
    for name in ('adapter/live-source-context.json','adapter/image-source-context.json'):
        modules['strata_exec_live']._module_preimages(bundle,name)
    for member,record in changes.items():
        if sha(Path(record['source']).read_bytes())!=record['sha256']:raise ValueError('production source changed during assembly')
    write(RECEIPTS/'verification.json',{'status':'static_records_and_both_source_contexts_verified_live_pending','identity':identity,'native_execution':False,'qualified':False,'elapsed_s':time.monotonic()-start})
    print(json.dumps({'status':'static_records_and_both_source_contexts_verified_live_pending','identity_sha256':identity['identity_sha256']}),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException as exc:
        if RECEIPTS.exists():write(RECEIPTS/'failure.json',{'type':type(exc).__name__,'error':str(exc)})
        raise