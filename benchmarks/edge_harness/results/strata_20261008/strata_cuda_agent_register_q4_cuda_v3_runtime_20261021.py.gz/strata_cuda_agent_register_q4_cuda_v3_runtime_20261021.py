import hashlib,json,sys,traceback
from pathlib import Path
ROOT=Path('C:/Users/zhout/w2/strata-omni')
REPO=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge')
OUT=ROOT/'runs/q4-execution-cuda-v3-20261021'
RUNTIME=ROOT/'runtime/e39-v6-cuda-v3'
PARENT=ROOT/'runs/q4-8g-20261008-1840/launch.json'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8') as f: json.dump(value,f,indent=2); f.write('\n')
sys.path.insert(0,str(REPO))
from benchmarks.edge_harness.strata_runtime import register_runtime_variant
from vllm_omni.engine.weight_tiers import ArtifactManifest,ArtifactFile
if OUT.exists(): raise RuntimeError('fresh output required')
import threading,time,psutil
profile_stop=threading.Event()
profile_path=ROOT/'prototypes/cuda-v3-registration-resources-20261021.jsonl'
def profile():
    process=psutil.Process()
    with profile_path.open('x',encoding='utf-8') as stream:
        stream.write(json.dumps({'scope':'registration process tree; logical IO is not physical SSD IO','pid':process.pid,'created':process.create_time()})+'\n')
        while not profile_stop.is_set():
            rows=[]
            for item in [process,*process.children(recursive=True)]:
                try:
                    rows.append(dict(pid=item.pid,created=item.create_time(),memory=item.memory_info()._asdict(),cpu=item.cpu_times()._asdict(),io=item.io_counters()._asdict()))
                except psutil.Error: pass
            stream.write(json.dumps({'time':time.time(),'processes':rows,'system_available_ram':psutil.virtual_memory().available})+'\n');stream.flush()
            profile_stop.wait(1)
profile_thread=threading.Thread(target=profile,daemon=True);profile_thread.start()
parent_raw=PARENT.read_bytes()
if sha(parent_raw)!='cb2fbfb2cdb6fefdb342c7429fa6075ae8475d03fbf548f2e752f0a06a62c314': raise ValueError('parent changed')
verified_raw=(ROOT/'prototypes/cuda-v3-context-refresh-20261021/verification.json').read_bytes()
verified=json.loads(verified_raw)
if verified['status']!='static_records_and_both_source_contexts_verified_live_pending' or verified['native_execution'] is not False: raise ValueError('static verification incomplete')
identity=verified['identity']
raw=(RUNTIME/'members.json').read_bytes()
if sha(raw)!=identity['runtime_manifest_sha256']: raise ValueError('members changed')
metadata=json.loads(parent_raw)['backend']['runtime_manifest']
metadata['files']=[ArtifactFile(r['path'],r['size_bytes'],r['sha256'],role='runtime').__dict__ for r in json.loads(raw)['files']]
metadata['files'].append(ArtifactFile('members.json',len(raw),sha(raw),role='runtime').__dict__)
manifest=ArtifactManifest.from_dict(metadata)
config=dict(schema='omni-strata-execution-observation-config-v1',descriptor_file='descriptor.json',static_identity_sha256=identity['identity_sha256'],source_context_file='adapter/live-source-context.json',receipt_root=str(ROOT/'observations/execution-cuda-v3-q4-20261021'),workspace_bytes=2<<30,receipt_storage_bytes=16<<20)
if Path(config['receipt_root']).exists(): raise RuntimeError('fresh observation directory required')
OUT.mkdir(); Path(config['receipt_root']).mkdir()
receipt=dict(status='running',native_model_executed=False,qualification_created=False,static_receipt_sha256=sha(verified_raw),producer_source_sha256=sha(Path(__file__).read_bytes()))
write(OUT/'runtime-manifest.json',manifest.to_dict());write(OUT/'execution-config.json',config)
try:
    result=register_runtime_variant(PARENT,runtime_root=RUNTIME,runtime_manifest_path=OUT/'runtime-manifest.json',execution_observation=config,launch_out=OUT/'launch.json',route_id='unsloth-q4-8g-execution-cuda-v3-20261021')
    receipt.update(status=result['status'],launch_sha256=sha((OUT/'launch.json').read_bytes()))
except BaseException:
    receipt.update(status='failed',traceback=traceback.format_exc());raise
finally:
    write(OUT/'registration-attempt.json',receipt)
    profile_stop.set();profile_thread.join(timeout=5)
print(json.dumps(receipt),flush=True)