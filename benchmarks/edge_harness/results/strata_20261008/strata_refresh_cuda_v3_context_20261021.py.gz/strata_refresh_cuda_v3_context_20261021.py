from pathlib import Path
import sys,json,hashlib,time
root=Path('C:/Users/zhout/w2/strata-omni');repo=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge');sys.path.insert(0,str(repo))
from vllm_omni.engine.backends import strata,strata_vision
out=root/'runtime/e39-v6-cuda-v3';log=root/'prototypes/cuda-v3-context-refresh-20261021';log.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(out/'members.json').read_bytes();(log/'members.before.json').write_bytes(raw)
rows=json.loads(raw)['files']; indexed={r['path']:r for r in rows};changes={};start=time.perf_counter()
def replace(member,data):
 old=(out/member).read_bytes();assert sha(old)==indexed[member]['sha256'],member
 (log/(member.replace('/','_')+'.before')).write_bytes(old)
 (out/member).write_bytes(data);indexed[member].update(size_bytes=len(data),sha256=sha(data));changes[member]=dict(before=sha(old),after=sha(data))
for member,source in {'adapter/omni_strata_stage.py':Path(strata.__file__),'adapter/strata_vision.py':Path(strata_vision.__file__),'adapter/strata_multimodal.py':repo/'vllm_omni/engine/backends/strata_multimodal.py'}.items(): replace(member,source.read_bytes())
for name,image in [('adapter/live-source-context.json',False),('adapter/image-source-context.json',True)]:
 context=json.loads((out/name).read_bytes())
 for row in context['modules']:row['sha256']=sha((out/row['member']).read_bytes())
 bootstrap=(strata_vision.bootstrap_source(strata._EXECUTION_BOOTSTRAP) if image else strata._EXECUTION_BOOTSTRAP).encode()
 if image:replace(context['bootstrap_member'],bootstrap)
 else:assert (out/context['bootstrap_member']).read_bytes()==bootstrap
 context['bootstrap_sha256']=sha(bootstrap)
 replace(name,json.dumps(context,indent=2).encode())
(out/'members.json').write_text(json.dumps(dict(schema='omni-strata-combined-members-v2',files=rows),indent=2),encoding='utf-8')
(log/'changes.json').write_text(json.dumps(changes,indent=2),encoding='utf-8');print('source context refreshed; verifying',flush=True)
modules=strata._load_execution_adapters(out,{(out/r['path']).resolve() for r in rows})
identity=modules['strata_exec_runtime'].verify_combined_runtime('descriptor.json',out)
bundle=modules['strata_exec_live']._reopen_static_bundle(out,json.loads((out/'descriptor.json').read_bytes()),identity)
for name in ['adapter/live-source-context.json','adapter/image-source-context.json']: modules['strata_exec_live']._module_preimages(bundle,name)
result=dict(status='static_records_and_both_source_contexts_verified_live_pending',identity=identity,changes=changes,elapsed_seconds=time.perf_counter()-start,native_execution=False)
(log/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'passed':True,'identity':identity['identity_sha256'],'seconds':result['elapsed_seconds']}),flush=True)
