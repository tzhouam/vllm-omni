import hashlib,json,sys,traceback,time
from pathlib import Path
R=Path('C:/Users/zhout/w2/strata-omni')
repo=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge')
sys.path.insert(0,str(repo))
from benchmarks.edge_harness.strata_vision_register import register_cpu_image_route
parent=R/'runs/q4-execution-combined-20261013-v6'
out=R/'runs/q4-image-execution-6g-20261014-v6'
raw=(parent/'launch.json').read_bytes()
attempt=json.loads((parent/'registration-attempt.json').read_bytes())
if attempt['status']!='registered_not_executed' or hashlib.sha256(raw).hexdigest()!=attempt['launch_sha256']:raise ValueError('successful unchanged text registration required')
if out.exists():raise RuntimeError('fresh output required')
out.mkdir()
receipt=dict(status='running',model_executed=False,started_unix=time.time(),text_launch_sha256=attempt['launch_sha256'],script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
try:
    result=register_cpu_image_route(parent/'launch.json',text_registration_path=parent/'launch.registration.json',image_route=json.loads((R/'prototypes/q4-image-v5-20261012/image-route.json').read_bytes()),launch_out=out/'launch.json',route_id='unsloth-q4-6g-image-execution-e39-v6-experimental',max_io_bytes=8<<20,execution_source_context_file='adapter/image-source-context.json',expert_ram_budget_bytes=6<<30)
    receipt.update(status=result['status'],launch_sha256=hashlib.sha256((out/'launch.json').read_bytes()).hexdigest())
except BaseException:
    receipt.update(status='failed',traceback=traceback.format_exc());raise
finally:
    receipt['finished_unix']=time.time()
    (out/'attempt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)