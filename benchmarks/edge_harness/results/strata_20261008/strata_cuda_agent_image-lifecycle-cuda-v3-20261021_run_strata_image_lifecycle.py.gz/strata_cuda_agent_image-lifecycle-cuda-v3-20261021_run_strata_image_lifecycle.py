"""Private CUDA image -> Strata language lifecycle; execution requires frozen review.

No import-time engine/model work. Text/reference quality, image/role bindings and
cancellation are functional evidence only; no default or performance promotion.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import copy
import hashlib
import json
import os
import re
import struct
import sys
import time
import traceback
import uuid
from pathlib import Path
from types import SimpleNamespace

ROOT = Path("C:/Users/zhout/w2/strata-omni")
REPO = Path(r"\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge")
SCHEMA = "omni-private-strata-cuda-image-lifecycle-v1"
BACKEND = "external.strata.multimodal.v1"
BASE_OWNER = ROOT / "run_observed_strata_lifecycle.py"
IMAGE_SHA = "73d64724eda2368d71213378caeeab0996ca405959ded5a0c1d2e3ff47c87c5e"
IMAGE_PATH = ROOT / "runs/q4-observed-final-8g-20261008-212822/qt-agent-final-v2/window.png"


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def object_file(path, limit=8 << 20):
    path = Path(path).resolve(strict=True)
    if path.stat().st_size > limit:
        raise ValueError("bounded metadata size exceeded")

    def unique(rows):
        result = {}
        for key, value in rows:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result

    value = json.loads(
        path.read_text(encoding="utf-8"),
        object_pairs_hook=unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")),
    )
    if not isinstance(value, dict):
        raise ValueError("metadata must be an object")
    return value


def save(path, value, *, exclusive=False):
    with Path(path).open("x" if exclusive else "w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def source_identity():
    paths = set((REPO / "vllm_omni").rglob("*.py"))
    paths.update((REPO / "packages/omni-stage-contracts").rglob("*.py"))
    paths.update(
        REPO / name
        for name in (
            "benchmarks/edge_harness/strata_profile.py",
            "benchmarks/edge_harness/strata_runtime.py",
            "benchmarks/edge_harness/strata_vision_register.py",
        )
    )
    paths.update((Path(__file__).resolve(), BASE_OWNER))
    if not paths or any(not path.is_file() for path in paths):
        raise ValueError("complete source/helper identity unavailable")
    return {str(path.resolve()): file_hash(path) for path in sorted(paths)}


def metadata_preflight(launch_path, reference_path):
    launch_path, reference_path = Path(launch_path).resolve(strict=True), Path(reference_path).resolve(strict=True)
    launch, reference = object_file(launch_path, 16 << 20), object_file(reference_path, 64 << 10)
    backend = launch["backend"]
    registration_path = launch_path.with_suffix(".image-registration.json")
    registration = object_file(registration_path)
    if (
        launch.get("schema") != "omni-strata-launch-v1"
        or backend.get("name") != BACKEND
        or backend.get("image_route", {}).get("encoder_device") != "cuda"
        or backend["image_route"].get("allow_cpu_fallback") is not False
        or backend.get("spec_tokens") != 0
        or registration.get("schema") != "omni-strata-cuda-image-registration-v1"
        or registration.get("status") != "registered_experimental_image_not_executed"
        or registration.get("qualification_created") is not False
        or registration.get("default_route_created") is not False
        or registration.get("launch_canonical_sha256") != canonical(launch)
        or registration.get("route_id") != backend.get("route_id")
        or Path(registration["launch_out"]).resolve() != launch_path
        or not all(registration.get(key) == value for key, value in launch["image_registration"].items())
    ):
        raise ValueError("exact experimental image registration binding missing")
    identity = copy.deepcopy(registration["image_identity"])
    identity_sha = identity.pop("identity_sha256")
    if identity_sha != canonical(identity) or identity_sha != launch["image_registration"]["image_identity_sha256"]:
        raise ValueError("image identity preimage mismatch")
    names = {
        "image_registrar": REPO / "benchmarks/edge_harness/strata_vision_register.py",
        "runtime_registrar": REPO / "benchmarks/edge_harness/strata_runtime.py",
        "strata_backend": REPO / "vllm_omni/engine/backends/strata.py",
        "native_io_adapter": REPO / "vllm_omni/engine/backends/strata_io.py",
        "vision_adapter": REPO / "vllm_omni/engine/backends/strata_vision.py",
        "image_stage_backend": REPO / "vllm_omni/engine/backends/strata_multimodal.py",
    }
    for key, expected in launch["image_registration"]["source_code_sha256"].items():
        if key not in names or file_hash(names[key]) != expected:
            raise ValueError("image registration source changed")
    if set(launch["image_registration"]["source_code_sha256"]) != set(names):
        raise ValueError("image registration source identity incomplete")
    if (
        reference.get("schema") != "omni-private-real-app-image-reference-v1"
        or reference.get("image_sha256") != IMAGE_SHA
        or reference.get("width") != 1040
        or reference.get("height") != 760
        or Path(reference["image_path"]).resolve() != IMAGE_PATH.resolve()
        or not isinstance(reference.get("cases"), list)
        or len(reference["cases"]) != 2
    ):
        raise ValueError("approved closed application screenshot/reference required")
    image = IMAGE_PATH.read_bytes()
    if len(image) > backend["image_route"]["max_image_bytes"] or hashlib.sha256(image).hexdigest() != IMAGE_SHA:
        raise ValueError("image bytes changed or exceed admission")
    if len(image) < 24 or image[:8] != b"\x89PNG\r\n\x1a\n" or struct.unpack(">II", image[16:24]) != (1040, 760):
        raise ValueError("approved screenshot dimensions differ")
    ids = set()
    for case in reference["cases"]:
        if (
            set(case) != {"id", "prompt", "expected"}
            or not isinstance(case["id"], str)
            or not re.fullmatch("[a-z][a-z0-9_]{0,63}", case["id"])
            or case["id"] in ids
            or not isinstance(case["prompt"], str)
            or not case["prompt"]
            or not isinstance(case["expected"], str)
            or not case["expected"]
            or case["expected"].casefold() in case["prompt"].casefold()
        ):
            raise ValueError("unique visual task and separate non-spoonfed reference required")
        ids.add(case["id"])
    return (
        launch,
        reference,
        registration,
        {
            "launch_file_sha256": file_hash(launch_path),
            "registration_file_sha256": file_hash(registration_path),
            "reference_file_sha256": file_hash(reference_path),
            "image_sha256": IMAGE_SHA,
            "image_identity_sha256": identity_sha,
            "source": source_identity(),
        },
        image,
    )


def prepare_freeze(args):
    _, _, _, identity, _ = metadata_preflight(args.launch, args.reference)
    freeze = {
        "schema": SCHEMA + "-freeze",
        "input": identity,
        "scope": "approved code/metadata/image freeze only; no artifacts hashed or models loaded",
        "created_unix": time.time(),
    }
    target = Path(args.freeze).resolve()
    target.relative_to(ROOT.resolve())
    target.parent.mkdir(parents=True, exist_ok=True)
    save(target, freeze, exclusive=True)
    return {"freeze_sha256": file_hash(target), "schema": freeze["schema"]}


def guard():
    import psutil

    if os.name != "nt":
        raise RuntimeError("native Windows required")
    own = {os.getpid(), *(p.pid for p in psutil.Process().parents())}
    blocked = []
    for p in psutil.process_iter(["pid", "name", "cmdline"]):
        if p.pid in own:
            continue
        name, command = (p.info.get("name") or "").casefold(), p.info.get("cmdline") or []
        owned = False
        for raw in command:
            path = Path(raw.strip('"')).resolve(strict=False)
            if (
                path.is_relative_to(ROOT.resolve())
                and path.name.casefold().startswith(("run_", "prepare_", "register_"))
                and path.suffix.casefold() == ".py"
            ):
                owned = True
        if name in {"strata.exe", "strata-vision.exe", "llama-server.exe"} or owned:
            blocked.append({"pid": p.pid, "name": name})
    if blocked:
        raise RuntimeError("an owned model/preparation/registration/runner is active: " + json.dumps(blocked))
    return {"checked_unix": time.time(), "owned_model_and_runner_absent": True}


def runtime_api():
    sys.dont_write_bytecode = True
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    sys.path.insert(0, str(REPO))
    from vllm_omni.config.stage_config import (
        DeployConfig,
        PipelineConfig,
        StageDeployConfig,
        StageExecutionType,
        StagePipelineConfig,
        merge_pipeline_deploy,
    )
    from vllm_omni.edge.agent import strata_image_evidence as proof
    from vllm_omni.edge.agent.runtime_identity import loaded_runtime_identity, loaded_runtime_sha256
    from vllm_omni.engine.backends import strata_io, strata_vision
    from vllm_omni.engine.resource_ledger import ResourceLedger
    from vllm_omni.engine.stage_runtime import StageRuntime

    from benchmarks.edge_harness import strata_profile as profile

    class ImageStageDriver(profile.OmniStageDriver):
        async def start(self):
            if self.launch["backend"]["name"] != BACKEND:
                raise ValueError("only the distinct registered image backend is accepted")
            pipeline = PipelineConfig(
                model_type="strata_whole_model_image",
                stages=(
                    StagePipelineConfig(
                        stage_id=0,
                        model_stage="multimodal",
                        execution_type=StageExecutionType.GRAPH,
                        final_output=True,
                        final_output_type="text",
                    ),
                ),
            )
            deploy = DeployConfig(
                async_chunk=False,
                stages=[
                    StageDeployConfig(
                        stage_id=0, backend=self.launch["backend"], resource_budget=self.launch["resource_budget"]
                    )
                ],
            )
            configs = [stage.to_omegaconf() for stage in merge_pipeline_deploy(pipeline, deploy)]
            self.runtime = StageRuntime(
                configs,
                "local-strata-image-lifecycle",
                "",
                async_chunk=False,
                stage_init_timeout=int(self.launch.get("stage_init_timeout_s", 900)),
                resource_ledger=self.resource_ledger,
            )
            await asyncio.to_thread(self.runtime.initialize)
            self.pool = self.runtime.stage_pools[0]
            self.client = self.pool.stage_client
            if self.telemetry is not None:
                self.telemetry.bind_process_identity_provider(self.client.gpu_observer_identity)
            return {
                "execution_plan": copy.deepcopy(self.client.execution_plan),
                "ledger": self.runtime.resource_ledger.snapshot(),
                "loaded_client_module": type(self.client).__module__,
            }

    return SimpleNamespace(
        profile=profile,
        io=strata_io,
        vision=strata_vision,
        proof=proof,
        Ledger=ResourceLedger,
        Driver=ImageStageDriver,
        loaded_identity=loaded_runtime_identity,
        loaded_sha=loaded_runtime_sha256,
    )


def validate_native(io, report, plan, request_id, epoch, expected_seq):
    owner = plan["selected_native_module_audit_at_load"]
    if (
        report.get("schema") != ("omni-strata-combined-request-io-observation-v1"
                               if plan.get("route_controls", {}).get("execution_observation") is not None
                               else "omni-strata-request-io-observation-v1")
        or report.get("status") != "complete"
        or report.get("request_id") != request_id
        or report.get("epoch") != epoch
        or report.get("generation") != plan["worker_generation"]
        or report.get("native_request_seq") != expected_seq
        or report.get("native_pid") != owner["pid"]
        or report.get("creation_filetime_100ns") != owner["creation_filetime_100ns"]
        or report.get("runtime_identity_sha256") != plan["observation_runtime"]["identity_sha256"]
        or report.get("scope") != io.SCOPE
        or report.get("physical_ssd_read_bytes") is not None
        or report.get("loading_covered") is not False
        or report.get("three_tier_memory_qualified") is not False
        or report.get("reasons") != []
        or report.get("native_terminal") != "stop"
        or report.get("snapshot_consistency") != "independent_atomic_counters_not_global_transaction"
        or report.get("attribution")
        != "counter_differences_during_owned_boundary_intervals_may_include_background_work"
    ):
        raise ValueError("native report identity/terminal/scope is not complete")
    rows = report["raw_snapshots"]
    if len(rows) != 3 or [row["phase"] for row in rows] != list(io.PHASES):
        raise ValueError("ordered native boundaries missing")
    for row in rows:
        io.validate_snapshot(row)
        if row["request_seq"] != expected_seq:
            raise ValueError("native boundary sequence mismatch")
    groups = (("expert", io.EXPERT_INTS | io.EXPERT_FLOATS), ("ple", io.PLE_INTS | io.PLE_FLOATS))
    for first, last in zip(rows, rows[1:]):
        if (
            first["qpc_hz"] != last["qpc_hz"]
            or first["qpc"] > last["qpc"]
            or any(last[group][key] < first[group][key] for group, keys in groups for key in keys)
        ):
            raise ValueError("native clock/counter decreased")
    expected = {}
    for name, first, last in (
        ("prefill", rows[0], rows[1]),
        ("decode", rows[1], rows[2]),
        ("whole_native_interval", rows[0], rows[2]),
    ):
        expected[name] = {
            group: {key: last[group][key] - first[group][key] for key in keys} for group, keys in groups
        } | {"boundary_wall_s": (last["qpc"] - first["qpc"]) / first["qpc_hz"]}
    if expected != report["intervals"] or any(
        expected["whole_native_interval"][group][key] for group, keys in io.ERROR_KEYS.items() for key in keys
    ):
        raise ValueError("native interval/error counter evidence differs")


def capture_sve(client, report, out):
    result = report["encode_result"]
    bounds = client.execution_plan["image_route"]["bounds_and_declared_budgets"]
    if (
        type(result["sve_bytes"]) is not int
        or not 20 < result["sve_bytes"] <= 20 + 4 * bounds["embedding_width"] * bounds["max_image_tokens"]
    ):
        raise ValueError("SVE snapshot exceeds admitted encoder-output bound")
    scratch = Path(client._temporary.name).resolve(strict=True) / "vision-scratch"
    matches = []
    for path in scratch.glob("*.sve"):
        resolved = path.resolve(strict=True)
        if not resolved.is_relative_to(scratch) or resolved.stat().st_size != result["sve_bytes"]:
            continue
        if file_hash(resolved) == result["sve_sha256"]:
            matches.append(resolved)
    if not matches:
        raise ValueError("completed owned encoder SVE bytes are unavailable")
    source = sorted(matches)[0]
    before = (source.stat().st_size, source.stat().st_mtime_ns)
    data = source.read_bytes()
    if (
        len(data) != result["sve_bytes"]
        or hashlib.sha256(data).hexdigest() != result["sve_sha256"]
        or before != (source.stat().st_size, source.stat().st_mtime_ns)
    ):
        raise ValueError("SVE changed during post-terminal snapshot")
    header = struct.unpack("<5i", data[:20])
    width = client.execution_plan["image_route"]["bounds_and_declared_budgets"]["embedding_width"]
    if header != (0x31455653, result["image_tokens"], result["nx"], result["ny"], width):
        raise ValueError("persisted SVE header differs from owned encode")
    with out.open("xb") as stream:
        stream.write(data)
    return {
        "size_bytes": len(data),
        "sha256": file_hash(out),
        "scope": "post-terminal owned SVE snapshot matching encode and GENI hashes",
    }


def encoder_window(client, request_id, image_sha, expected_seq):
    observer = client._encoder_observer
    with observer._lock:
        active = copy.deepcopy(observer.active)
        identity, backend = copy.deepcopy(observer.identity), copy.deepcopy(observer.backend)
        retired = observer.retired
    if retired:
        raise ValueError("encoder observer retired before cancellation window")
    if active is None:
        return None
    if active["request_id"] != request_id or active["image_sha256"] != image_sha:
        raise ValueError("foreign encoder active request")
    if active["start"] is None:
        return None
    if active["end"] is not None or active["dispatch"] is not None:
        raise ValueError("encoder cancellation window already ended")
    if (
        active["native_encoder_request_seq"] != expected_seq
        or identity != client.execution_plan["owned_encoder_at_load"]
        or backend != client.execution_plan["encoder_backend_selection_at_load"]
    ):
        raise ValueError("encoder cancellation phase owner/sequence mismatch")
    return {
        "request_id": request_id,
        "epoch": active["epoch"],
        "generation": client.execution_plan["worker_generation"],
        "native_encoder_request_seq": expected_seq,
        "owned_encoder": identity,
        "backend_selection": backend,
        "input_sha256": image_sha,
        "encode_start": active["start"],
        "encode_end": None,
        "language_dispatch": None,
        "observed_monotonic_s": time.perf_counter(),
    }


def require_empty_ledger(snapshot):
    if (
        not isinstance(snapshot, dict)
        or snapshot.get("owners") != []
        or snapshot.get("quarantined") != []
        or not isinstance(snapshot.get("reserved"), dict)
        or any(type(value) is not int or value != 0 for value in snapshot["reserved"].values())
    ):
        raise ValueError("completed image lifecycle retains or quarantines resources")


def verify_completed_lifecycle(receipt_path, launch_path, *, expected_receipt_sha256, expected_runner_sha256):
    """Read-only stdlib closure gate for a later Agent image runner.

    This verifies existing functional evidence. It never executes models or
    upgrades its narrow task/placement/memory qualification scope.
    """
    receipt_path = Path(receipt_path).resolve(strict=True)
    root = receipt_path.parent
    receipt = object_file(receipt_path)
    if (
        file_hash(receipt_path) != expected_receipt_sha256
        or file_hash(Path(__file__)) != expected_runner_sha256
        or receipt.get("script_sha256") != expected_runner_sha256
        or receipt.get("schema") != SCHEMA
        or receipt.get("phase") != "completed"
        or any(
            receipt.get(key) is not True
            for key in (
                "resource_drain_verified",
                "source_stable",
                "input_stable",
                "encoder_phase_cancel_passed",
                "fresh_generation_image_recovery_passed",
            )
        )
        or receipt.get("physical_ssd_read_bytes") is not None
        or receipt.get("release_qualified") is not False
        or receipt.get("three_tier_memory_qualified") is not False
        or receipt.get("batch_size") != 1
        or receipt.get("concurrency") != 1
        or receipt.get("telemetry", {}).get("sampling_thread_stopped") is not True
        or receipt.get("unhashed_mutable_files")
        or receipt.get("source_before") != receipt.get("source_after")
        or receipt.get("source_before") != source_identity()
        or receipt.get("initial_exact_roles_retired") != {"encoder": True, "language": True}
        or canonical(receipt.get("loaded_python_runtime_identity")) != receipt.get("loaded_python_runtime_sha256")
        or Path(receipt.get("launch_file", "")).resolve() != Path(launch_path).resolve(strict=True)
        or file_hash(launch_path) != receipt["input_identity"]["launch_file_sha256"]
    ):
        raise ValueError("exact completed frozen image lifecycle prerequisite unavailable")
    require_empty_ledger(receipt["ledger_final"])
    raw = receipt["raw_files"]
    actual = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file() and path != receipt_path}
    if not isinstance(raw, dict) or actual != set(raw):
        raise ValueError("image lifecycle raw closure has missing or additional files")
    for rel, identity in raw.items():
        path = (root / rel).resolve(strict=True)
        if (
            not path.is_relative_to(root)
            or path.stat().st_size != identity["size_bytes"]
            or file_hash(path) != identity["sha256"]
        ):
            raise ValueError("image lifecycle raw file differs from closure")
    if (
        file_hash(root / "effective-launch.json") != receipt["input_identity"]["launch_file_sha256"]
        or file_hash(root / "reference.json") != receipt["input_identity"]["reference_file_sha256"]
        or file_hash(root / "input.png") != IMAGE_SHA
    ):
        raise ValueError("closed input copies differ from frozen launch/reference/image")
    plans = {}
    for name in ("initial", "recovery"):
        plan = plans[name] = object_file(root / (name + "-loaded-plan.json"))["execution_plan"]
        close = object_file(root / (name + "-close.json"))
        if (
            canonical(plan) != receipt[name + "_loaded_plan_sha256"]
            or plan.get("backend") != BACKEND
            or plan["route_controls_sha256"] != receipt[name + "_route_controls_sha256"]
            or plan["image_route"]["identity_sha256"] != receipt[name + "_image_identity_sha256"]
            or canonical(plan["route_controls"]) != plan["route_controls_sha256"]
            or plan["route_controls"].get("image_route") != plan["image_route"]
            or close.get("exact_role_retirement") != {"encoder": True, "language": True}
        ):
            raise ValueError("image lifecycle loaded plan/control or both-role retirement differs")
        require_empty_ledger(close["ledger_after_shutdown"])
    if (
        plans["initial"]["worker_generation"] == plans["recovery"]["worker_generation"]
        or plans["initial"]["route_controls"] != plans["recovery"]["route_controls"]
        or plans["initial"]["owned_encoder_at_load"] == plans["recovery"]["owned_encoder_at_load"]
        or (
            plans["initial"]["selected_native_module_audit_at_load"]["pid"],
            plans["initial"]["selected_native_module_audit_at_load"]["creation_filetime_100ns"],
        )
        == (
            plans["recovery"]["selected_native_module_audit_at_load"]["pid"],
            plans["recovery"]["selected_native_module_audit_at_load"]["creation_filetime_100ns"],
        )
    ):
        raise ValueError("image recovery did not preserve controls and create a fresh generation")
    cancelled = object_file(root / "encoder-cancellation.json")
    cancel_image = cancelled["image_observation"]
    cancel_io = cancelled["native_io_observation"]
    window = cancelled["window"]
    language = plans["initial"]["selected_native_module_audit_at_load"]
    if (
        cancelled.get("status") != "cancelled_during_observed_encoder_phase"
        or cancelled.get("exact_role_retirement") != {"encoder": True, "language": True}
        or cancelled.get("cancel", {}).get("drained") is not True
        or window.get("generation") != plans["initial"]["worker_generation"]
        or window.get("owned_encoder") != plans["initial"]["owned_encoder_at_load"]
        or window.get("backend_selection") != plans["initial"]["encoder_backend_selection_at_load"]
        or window.get("native_encoder_request_seq") != 3
        or window.get("input_sha256") != IMAGE_SHA
        or window.get("encode_start", {}).get("image_sha256") != IMAGE_SHA
        or window.get("encode_end") is not None
        or window.get("language_dispatch") is not None
        or not (
            0
            < window["observed_monotonic_s"]
            <= cancelled["cancel_call_started_monotonic_s"]
            <= cancelled["cancel_call_finished_monotonic_s"]
        )
        or cancel_image.get("status") != "incomplete"
        or cancel_image.get("encode_result") is not None
        or cancel_image.get("language_dispatch") is not None
        or cancel_image.get("native_encoder_request_seq") != 3
        or cancel_image.get("generation") != plans["initial"]["worker_generation"]
        or cancel_image.get("request_id") != cancelled["window"]["request_id"]
        or cancel_image.get("epoch") != cancelled["window"]["epoch"]
        or cancel_image.get("owned_encoder") != window["owned_encoder"]
        or cancel_image.get("input_sha256") != IMAGE_SHA
        or not cancel_image.get("reasons")
        or cancel_image.get("physical_ssd_read_bytes") is not None
        or cancel_image.get("release_qualified") is not False
        or cancel_io.get("status") != "incomplete"
        or cancel_io.get("request_id") != cancel_image["request_id"]
        or cancel_io.get("epoch") != cancel_image["epoch"]
        or cancel_io.get("generation") != cancel_image["generation"]
        or cancel_io.get("native_request_seq") is not None
        or cancel_io.get("raw_snapshots") != []
        or cancel_io.get("native_terminal") is not None
        or cancel_io.get("native_pid") != language["pid"]
        or cancel_io.get("creation_filetime_100ns") != language["creation_filetime_100ns"]
        or cancel_io.get("runtime_identity_sha256") != plans["initial"]["observation_runtime"]["identity_sha256"]
        or cancel_io.get("physical_ssd_read_bytes") is not None
        or cancel_io.get("loading_covered") is not False
        or cancel_io.get("three_tier_memory_qualified") is not False
        or object_file(root / "after-cancel-loaded-plan.json") != plans["initial"]
    ):
        raise ValueError("closed encoder-phase cancellation or plan immutability proof differs")
    require_empty_ledger(object_file(root / "after-cancel-ledger.json"))
    rows = receipt.get("requests")
    if not isinstance(rows, list) or [
        (row.get("phase"), row.get("native_seq"), row.get("encoder_seq")) for row in rows
    ] != [("initial", 1, 1), ("initial", 2, 2), ("recovery", 1, 1)]:
        raise ValueError("image lifecycle lacks its three complete request identities")
    states, request_ids = set(), set()
    for row in rows:
        proof_path = (root / row["proof_file"]).resolve(strict=True)
        if not proof_path.is_relative_to(root) or proof_path.relative_to(root).as_posix() not in raw:
            raise ValueError("image proof must belong to the closed raw evidence")
        proof = object_file(proof_path)
        raw_row = object_file(root / (row["phase"] + "-" + row["case_id"] + ".json"))
        stage = proof["stage_event"]
        state = (stage["worker_generation"], stage["epoch"])
        if (
            row.get("quality_passed") is not True
            or row.get("finish_reason") != "stop"
            or raw_row.get("status") != "completed"
            or raw_row.get("quality", {}).get("passed") is not True
            or raw_row.get("finish_reason") != "stop"
            or raw_row.get("request_id") != row["request_id"]
            or raw_row.get("stage_events", [])[-1:] != [stage]
            or raw_row.get("metrics", {}).get("runtime_telemetry", {}).get("image_observation")
            != proof["image_observation"]
            or raw_row.get("metrics", {}).get("runtime_telemetry", {}).get("native_io_observation")
            != proof["native_io_observation"]
            or state in states
            or row["request_id"] in request_ids
            or canonical(proof) != row["proof_sha256"]
            or proof.get("request_id") != row["request_id"]
            or proof.get("loaded_plan_sha256") != receipt[row["phase"] + "_loaded_plan_sha256"]
            or proof.get("input", {}).get("sha256") != IMAGE_SHA
            or proof.get("physical_ssd_read_bytes") is not None
            or proof.get("release_qualified") is not False
            or proof["image_observation"].get("status") != "complete"
            or proof["image_observation"].get("native_encoder_request_seq") != row["encoder_seq"]
            or proof["native_io_observation"].get("status") != "complete"
            or proof["native_io_observation"].get("native_request_seq") != row["native_seq"]
            or stage["worker_generation"] != plans[row["phase"]]["worker_generation"]
        ):
            raise ValueError("closed image functional proof or quality identity differs")
        sve_path = root / (row["phase"] + "-" + row["case_id"] + ".sve")
        result = proof["image_observation"]["encode_result"]
        if (
            file_hash(sve_path) != row["sve_sha256"]
            or row["sve_sha256"] != result["sve_sha256"]
            or sve_path.stat().st_size != result["sve_bytes"]
        ):
            raise ValueError("closed actual SVE bytes differ from completed image chain")
        states.add(state)
        request_ids.add(row["request_id"])
    return {
        "schema": SCHEMA + "-prerequisite",
        "receipt_sha256": expected_receipt_sha256,
        "runner_sha256": expected_runner_sha256,
        "raw_closure_verified": True,
        "image_identity_sha256": receipt["initial_image_identity_sha256"],
        "route_controls_sha256": receipt["initial_route_controls_sha256"],
        "generations": [plans[name]["worker_generation"] for name in ("initial", "recovery")],
        "scope": (
            "closed three narrow real-app image requests plus encoder-phase cancel/recovery; "
            "no default or performance qualification"
        ),
    }


async def cancel_encoder(driver, client, prompt, api, expected_seq, owners):
    request_id = "strata-image-cancel-" + uuid.uuid4().hex
    await driver.pool.submit_initial(
        request_id, SimpleNamespace(sampling_params_list=[None]), dict(prompt, stream_agent=True)
    )
    deadline = time.perf_counter() + 300
    window = None
    try:
        while time.perf_counter() < deadline:
            window = encoder_window(client, request_id, IMAGE_SHA, expected_seq)
            if window is not None:
                break
            await asyncio.sleep(0.001)
        if window is None:
            raise TimeoutError("no actual encoder-in-flight cancellation window observed")
        if any(owner.state() != "alive" for owner in owners.values()):
            raise ValueError("exact encoder/language handles not live at cancellation")
        cancel_started = time.perf_counter()
        cancelled = await driver.cancel(request_id)
        cancel_finished = time.perf_counter()
    except BaseException:
        try:
            await driver.cancel(request_id)
        finally:
            raise
    image, io = client.last_image_observation(), client.last_io_observation()
    if (
        cancelled.get("drained") is not True
        or image is None
        or image.get("status") != "incomplete"
        or image.get("request_id") != request_id
        or image.get("epoch") != window["epoch"]
        or image.get("generation") != window["generation"]
        or image.get("owned_encoder") != window["owned_encoder"]
        or image.get("input_sha256") != IMAGE_SHA
        or image.get("native_encoder_request_seq") != expected_seq
        or image.get("encode_result") is not None
        or image.get("language_dispatch") is not None
        or not image.get("reasons")
        or image.get("physical_ssd_read_bytes") is not None
        or image.get("release_qualified") is not False
        or io is None
        or io.get("status") != "incomplete"
        or io.get("request_id") != request_id
        or io.get("epoch") != window["epoch"]
        or io.get("generation") != window["generation"]
        or io.get("native_request_seq") is not None
        or io.get("raw_snapshots") != []
        or io.get("native_terminal") is not None
        or io.get("physical_ssd_read_bytes") is not None
        or io.get("loading_covered") is not False
    ):
        raise ValueError("encoder-phase cancellation raced completion or lacks incomplete bound evidence")
    retirement = {role: owner.close_retired() for role, owner in owners.items()}
    if not all(retirement.values()):
        raise ValueError("exact encoder/language process retirement unverified; no recovery")
    api.profile.require_drained_ledger(driver.resource_ledger.snapshot())
    return {
        "schema": SCHEMA + "-encoder-cancel",
        "status": "cancelled_during_observed_encoder_phase",
        "window": window,
        "cancel_call_started_monotonic_s": cancel_started,
        "cancel_call_finished_monotonic_s": cancel_finished,
        "cancel": cancelled,
        "image_observation": image,
        "native_io_observation": io,
        "native_execution_observation": (client.last_execution_observation()
                                         if hasattr(client, "last_execution_observation") else None),
        "exact_role_retirement": retirement,
        "scope": "ENC start observed before end/GENI; race or access failure refuses, no phase inference",
    }


async def run(args):
    out = Path(args.output).resolve()
    out.relative_to(ROOT.resolve())
    launch, reference, registration, identity, image = metadata_preflight(args.launch, args.reference)
    immutable_roots = [
        Path(launch["backend"][key]).resolve() for key in ("runtime_root", "artifact_root", "prepared_model_dir")
    ]
    immutable_roots += [Path(launch["backend"]["image_route"]["projector_root"]).resolve(), IMAGE_PATH.parent.resolve()]
    if any(out.is_relative_to(root) for root in immutable_roots):
        raise ValueError("lifecycle output cannot enter immutable model/runtime/projector/closed screenshot evidence")
    if launch["backend"].get("log_file"):
        log = Path(launch["backend"]["log_file"]).resolve()
        if log.exists() or not log.is_relative_to(out):
            raise ValueError("native diagnostic log must be fresh and owned by this lifecycle output")
    freeze = object_file(args.freeze)
    if (
        file_hash(args.freeze) != args.expected_freeze_sha256
        or freeze.get("schema") != SCHEMA + "-freeze"
        or freeze.get("input") != identity
    ):
        raise ValueError("exact reviewed final-source/input freeze required")
    guarded = guard()
    out.mkdir(parents=True, exist_ok=False)
    for source, name, expected in (
        (args.launch, "effective-launch.json", identity["launch_file_sha256"]),
        (args.reference, "reference.json", identity["reference_file_sha256"]),
    ):
        data = Path(source).read_bytes()
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError("frozen metadata changed before its exact byte snapshot")
        with (out / name).open("xb") as stream:
            stream.write(data)
    (out / "input.png").write_bytes(image)
    receipt = {
        "schema": SCHEMA,
        "phase": "prepared",
        "script_sha256": file_hash(Path(__file__)),
        "freeze_sha256": file_hash(args.freeze),
        "input_identity": identity,
        "launch_file": str(Path(args.launch).resolve()),
        "reference_file": str(Path(args.reference).resolve()),
        "source_before": identity["source"],
        "requests": [],
        "guard": guarded,
        "batch_size": 1,
        "concurrency": 1,
        "scope": (
            "two real-app image tasks, actual encoder-phase cancellation and fresh image recovery; "
            "not performance/default/whole-model qualification"
        ),
        "physical_ssd_read_bytes": None,
        "three_tier_memory_qualified": False,
        "release_qualified": False,
        "started_unix": time.time(),
    }
    save(out / "receipt.json", receipt)
    drivers, clients, owners = {}, {}, {}
    telemetry = ledger = api = None
    before_source = identity["source"]
    seen, ids = set(), set()
    try:
        api = runtime_api()
        preimage = api.loaded_identity()
        loaded_sha = api.loaded_sha()
        if canonical(preimage) != loaded_sha:
            raise ValueError("actual imported runtime preimage differs from its SHA")
        receipt["loaded_python_runtime_identity"] = preimage
        receipt["loaded_python_runtime_sha256"] = loaded_sha
        ledger = api.Ledger(launch["resource_budget"]["capacities"])
        telemetry = api.profile.Telemetry(out / "telemetry.jsonl", 0.1)
        telemetry.start()
        options = api.profile.ProfileOptions(
            repeats=1, warmups=1, sustained_seconds=0, bands=("short",), request_timeout_s=600
        )
        data_url = "data:image/png;base64," + base64.b64encode(image).decode()
        input_identity = api.proof.image_input_identity(
            data_url, api.proof.image_capability_from_config(launch["backend"])
        )
        plans = {}
        for name in ("initial", "recovery"):
            if name == "recovery":
                api.profile.require_drained_ledger(ledger.snapshot())
            receipt["phase"] = name + "_loading"
            save(out / "receipt.json", receipt)
            driver = drivers[name] = api.Driver(launch, resource_ledger=ledger, telemetry=telemetry)
            started = time.perf_counter()
            loaded = await driver.start()
            receipt[name + "_start_s"] = time.perf_counter() - started
            client = clients[name] = driver.client
            plan = plans[name] = copy.deepcopy(client.execution_plan)
            if (
                type(client).__module__ != "vllm_omni.engine.backends.strata_multimodal"
                or type(client).__name__ != "StrataMultimodalStageClient"
            ):
                raise ValueError("actual registered client is not the complete-model image backend")
            api.proof.validate_image_load_plan_for_config(plan, launch["backend"], "cpu+cuda:0")
            if plan["image_route"] != registration["image_identity"]:
                raise ValueError("loaded image identity differs from exact registered preimage")
            save(out / (name + "-loaded-plan.json"), loaded)
            receipt[name + "_loaded_plan_sha256"] = canonical(plan)
            receipt[name + "_route_controls_sha256"] = plan["route_controls_sha256"]
            receipt[name + "_image_identity_sha256"] = plan["image_route"]["identity_sha256"]
            owners[name] = {
                role: api.vision.OwnedWindowsProcess(value)
                for role, value in {
                    "encoder": plan["owned_encoder_at_load"],
                    "language": {
                        key: plan["selected_native_module_audit_at_load"][key]
                        for key in ("pid", "creation_filetime_100ns")
                    },
                }.items()
            }
            if any(owner.state() != "alive" for owner in owners[name].values()):
                raise ValueError("both exact owned native roles must be live after load")
            if name == "recovery" and (
                plan["worker_generation"] == plans["initial"]["worker_generation"]
                or plan["route_controls"] != plans["initial"]["route_controls"]
                or plan["route_controls_sha256"] != plans["initial"]["route_controls_sha256"]
            ):
                raise ValueError("fresh recovery generation or same controls not preserved")
            cases = reference["cases"] if name == "initial" else reference["cases"][:1]
            previous_epoch = 0
            for index, fixture in enumerate(cases, 1):
                receipt["phase"] = name + "_" + fixture["id"]
                save(out / "receipt.json", receipt)
                case = {
                    "id": fixture["id"],
                    "length_band": "short",
                    "prompt": {
                        "text": fixture["prompt"],
                        "image_data_url": data_url,
                        "max_tokens": 128,
                        "temperature": 0,
                    },
                    "quality": {"kind": "exact_text", "expected": fixture["expected"]},
                }
                row = await api.profile.collect_request(driver, case, name, index, options)
                save(out / (name + "-" + fixture["id"] + ".json"), row)
                if (
                    row["status"] != "completed"
                    or row["quality"]["passed"] is not True
                    or row["finish_reason"] != "stop"
                    or row["request_id"] in ids
                ):
                    raise ValueError("natural reference image answer/unique request failed")
                ids.add(row["request_id"])
                terminal = row["stage_events"][-1]
                if terminal["epoch"] <= previous_epoch:
                    raise ValueError("image stage epoch reused or unordered")
                previous_epoch = terminal["epoch"]
                proof = api.proof.validate_image_terminal(
                    plan,
                    row["metrics"],
                    terminal,
                    request_id=row["request_id"],
                    input_identity=input_identity,
                    seen_states=seen,
                    execution_binding=api.proof.image_execution_binding(launch["backend"]),
                )
                if proof is None or proof["image_observation"]["native_encoder_request_seq"] != index:
                    raise ValueError("whole image chain/encoder sequence missing")
                validate_native(
                    api.io, proof["native_io_observation"], plan, row["request_id"], terminal["epoch"], index
                )
                if client.last_io_observation() != proof["native_io_observation"]:
                    raise ValueError("native getter differs from terminal proof")
                last_image = copy.deepcopy(client.last_image_observation())
                published_image = dict(proof["image_observation"])
                published_image.pop("text_native_io_request_seq", None)
                published_image.pop("text_native_io_scope", None)
                if last_image != published_image:
                    raise ValueError("image getter differs from terminal proof")
                save(out / (name + "-" + fixture["id"] + "-proof.json"), proof)
                sve = capture_sve(client, proof["image_observation"], out / (name + "-" + fixture["id"] + ".sve"))
                save(out / (name + "-" + fixture["id"] + "-sve.json"), sve)
                receipt["requests"].append(
                    {
                        "phase": name,
                        "case_id": fixture["id"],
                        "request_id": row["request_id"],
                        "quality_passed": True,
                        "finish_reason": "stop",
                        "full_response_s": row["full_response_s"],
                        "native_seq": index,
                        "encoder_seq": index,
                        "generation": plan["worker_generation"],
                        "loaded_plan_sha256": canonical(plan),
                        "proof_file": name + "-" + fixture["id"] + "-proof.json",
                        "proof_sha256": canonical(proof),
                        "sve_sha256": sve["sha256"],
                    }
                )
                if client.execution_plan != plan:
                    raise ValueError("loaded plan mutated during complete image request")
            if name == "initial":
                receipt["phase"] = "encoder_cancellation"
                save(out / "receipt.json", receipt)
                prompt = {
                    "text": reference["cases"][0]["prompt"],
                    "image_data_url": data_url,
                    "max_tokens": 128,
                    "temperature": 0,
                }
                cancellation = await cancel_encoder(driver, client, prompt, api, len(cases) + 1, owners[name])
                save(out / "encoder-cancellation.json", cancellation)
                if client.execution_plan != plan:
                    raise ValueError("loaded plan mutated during encoder cancellation")
                save(out / "after-cancel-loaded-plan.json", copy.deepcopy(client.execution_plan))
                save(out / "after-cancel-ledger.json", ledger.snapshot())
                receipt["encoder_phase_cancel_passed"] = True
                receipt["initial_exact_roles_retired"] = cancellation["exact_role_retirement"]
        receipt["fresh_generation_image_recovery_passed"] = True
        receipt["phase"] = "completed"
    except BaseException as exc:
        receipt.update(phase="failed", error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
    finally:
        closed = True
        for name in reversed(tuple(drivers)):
            try:
                result = await drivers[name].close()
                api.profile.require_drained_ledger(ledger.snapshot())
                roles = {role: owner.close_retired() for role, owner in owners.get(name, {}).items()}
                if set(roles) != {"encoder", "language"} or not all(roles.values()):
                    raise ValueError("both exact roles lack authoritative retirement")
                save(out / (name + "-close.json"), result | {"exact_role_retirement": roles})
            except BaseException as exc:
                closed = False
                save(out / (name + "-close-error.json"), {"error_type": type(exc).__name__, "error": str(exc)})
            if name in clients:
                try:
                    save(out / (name + "-last-image.json"), clients[name].last_image_observation())
                    save(out / (name + "-last-io.json"), clients[name].last_io_observation())
                except BaseException as exc:
                    closed = False
                    save(out / (name + "-getter-error.json"), {"error_type": type(exc).__name__})
        receipt["resource_drain_verified"] = closed and bool(drivers)
        receipt["ledger_final"] = ledger.snapshot() if ledger is not None else None
        try:
            receipt["telemetry"] = (
                telemetry.stop()
                if telemetry is not None
                else {"sampling_thread_stopped": True, "status": "not_started"}
            )
        except BaseException as exc:
            receipt["telemetry"] = {"sampling_thread_stopped": False, "stop_error_type": type(exc).__name__}
        sampler_stopped = receipt["telemetry"].get("sampling_thread_stopped") is True
        try:
            after_source = source_identity()
            receipt["source_after"] = after_source
            receipt["source_stable"] = after_source == before_source
        except BaseException as exc:
            receipt["source_stable"] = False
            receipt["source_check_error"] = type(exc).__name__ + ": " + str(exc)
        try:
            receipt["input_after"] = {
                key: value
                for key, value in metadata_preflight(args.launch, args.reference)[3].items()
                if key != "source"
            }
            receipt["input_stable"] = receipt["input_after"] == {
                key: value for key, value in identity.items() if key != "source"
            }
        except BaseException as exc:
            receipt["input_stable"] = False
            receipt["input_check_error"] = type(exc).__name__ + ": " + str(exc)
        if (
            not receipt["resource_drain_verified"]
            or not sampler_stopped
            or not receipt["source_stable"]
            or not receipt["input_stable"]
        ):
            receipt["phase"] = "failed"
        receipt["finished_unix"] = time.time()
        safe_to_hash = sampler_stopped and receipt["resource_drain_verified"]
        receipt["raw_files"] = {
            p.relative_to(out).as_posix(): {"size_bytes": p.stat().st_size, "sha256": file_hash(p)}
            for p in sorted(out.rglob("*"))
            if p.is_file() and p.name != "receipt.json" and safe_to_hash
        }
        if not safe_to_hash:
            receipt["unhashed_mutable_files"] = [
                p.relative_to(out).as_posix()
                for p in sorted(out.rglob("*"))
                if p.is_file() and p.name != "receipt.json"
            ]
        save(out / "receipt.json", receipt)
    print(
        json.dumps(
            {
                key: receipt.get(key)
                for key in (
                    "phase",
                    "resource_drain_verified",
                    "encoder_phase_cancel_passed",
                    "fresh_generation_image_recovery_passed",
                )
            }
        ),
        flush=True,
    )
    return 0 if receipt["phase"] == "completed" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("launch", "reference", "freeze"):
        parser.add_argument("--" + key, type=Path, required=True)
    parser.add_argument("--prepare-freeze", action="store_true")
    parser.add_argument("--expected-freeze-sha256")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.prepare_freeze:
        print(json.dumps(prepare_freeze(args)))
        return 0
    if not args.expected_freeze_sha256 or not args.output:
        parser.error("actual execution requires exact reviewed freeze SHA and exclusive output")
    return asyncio.run(run(args))


if __name__ == "__main__":
    raise SystemExit(main())
