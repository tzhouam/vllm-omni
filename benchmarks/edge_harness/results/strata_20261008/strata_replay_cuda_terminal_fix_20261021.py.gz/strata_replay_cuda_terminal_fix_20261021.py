"""Offline replay of captured CUDA evidence; no model or browser execution."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('C:/Users/zhout/w2/strata-omni')
REPO = Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge')
RUN = ROOT / 'runs/q4-cuda-v3-lifecycle-20261021'
OUT = ROOT / 'prototypes/cuda-terminal-offline-replay-20261021.json'
sys.path.insert(0, str(REPO))
from vllm_omni.edge.agent import strata_image_evidence as evidence

receipt = json.loads((RUN / 'receipt.json').read_bytes())
def read(name):
    raw = (RUN / name).read_bytes()
    if hashlib.sha256(raw).hexdigest() != receipt['raw_files'][name]['sha256']:
        raise ValueError('Captured raw evidence changed: ' + name)
    return json.loads(raw)

launch = read('effective-launch.json')
plan = read('initial-loaded-plan.json')['execution_plan']
row = read('initial-approval_heading.json')
assert receipt['phase'] == 'failed' and receipt['resource_drain_verified']
assert row['status'] == 'completed' and row['quality']['passed'] is True
evidence.validate_image_load_plan_for_config(plan, launch['backend'], 'cpu+cuda:0')
identity = evidence.image_input_identity(row['input']['image_data_url'],
    evidence.image_capability_from_config(launch['backend']))
seen = set()
kwargs = dict(request_id=row['request_id'], input_identity=identity, seen_states=seen,
    execution_binding=evidence.image_execution_binding(launch['backend']))
proof = evidence.validate_image_terminal(plan, row['metrics'], row['stage_events'][-1], **kwargs)
assert proof is not None and proof['release_qualified'] is False
try:
    evidence.validate_image_terminal(plan, row['metrics'], row['stage_events'][-1], **kwargs)
except ValueError:
    duplicate_rejected = True
else:
    raise AssertionError('Duplicate captured evidence was accepted')
result = dict(status='captured_cuda_terminal_replay_passed', duplicate_rejected=duplicate_rejected,
    source_sha256=hashlib.sha256(Path(evidence.__file__).read_bytes()).hexdigest(),
    captured_receipt_sha256=hashlib.sha256((RUN / 'receipt.json').read_bytes()).hexdigest(),
    raw_request_sha256=receipt['raw_files']['initial-approval_heading.json']['sha256'],
    proof=proof, qualification_created=False,
    scope='Offline validation of one previously captured correct CUDA request. Original failed lifecycle remains failed; fresh lifecycle still required.')
with OUT.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps({k:result[k] for k in ('status','duplicate_rejected','qualification_created')}), flush=True)
