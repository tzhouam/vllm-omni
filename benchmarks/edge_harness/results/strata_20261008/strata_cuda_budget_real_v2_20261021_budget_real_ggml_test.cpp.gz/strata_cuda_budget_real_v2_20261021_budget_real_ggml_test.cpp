
#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"
#include <algorithm>
#include <vector>
#include <limits>
#include <cstdlib>
#include <stdexcept>
#include <cstdio>
#include <string>
struct Sched{ggml_backend_sched_t value;ggml_backend_sched_t get(){return value;}};
struct clip_ctx{bool omni_budget_enabled=true;std::vector<ggml_backend_t> backend_ptrs;std::vector<ggml_backend_buffer_type_t> backend_buft;Sched sched;size_t omni_gpu_weights=0,omni_host_weights=0,omni_gpu_limit=0,omni_host_limit=0;};
static size_t omni_vision_budget_env(const char * name) {
    const char * value = std::getenv(name);
    if (!value || !*value) throw std::runtime_error("missing vision tensor budget");
    size_t result = 0;
    for (const char * p = value; *p; ++p) {
        if (*p < '0' || *p > '9' || result > (std::numeric_limits<size_t>::max() - (*p - '0')) / 10)
            throw std::runtime_error("invalid vision tensor budget");
        result = result * 10 + (*p - '0');
    }
    return result;
}
static size_t omni_vision_budget_add(size_t a, size_t b) {
    if (b > std::numeric_limits<size_t>::max() - a)
        throw std::runtime_error("vision tensor accounting overflow");
    return a + b;
}
static void omni_vision_budget_require(size_t gpu, size_t host, size_t gpu_limit, size_t host_limit) {
    if (gpu > gpu_limit || host > host_limit)
        throw std::runtime_error("vision explicit tensor budget exceeded before allocation");
}
static void omni_vision_check_graph_budget(clip_ctx & ctx, ggml_cgraph * graph) {
    if (!ctx.omni_budget_enabled) return;
    std::vector<size_t> retained(ctx.backend_ptrs.size()), planned(ctx.backend_ptrs.size());
    for (size_t i = 0; i < retained.size(); ++i)
        retained[i] = ggml_backend_sched_get_buffer_size(ctx.sched.get(), ctx.backend_ptrs[i]);
    // Measurement can release undersized buffers, but does not allocate device buffers.
    ggml_backend_sched_reserve_size(ctx.sched.get(), graph, planned.data());
    size_t gpu = ctx.omni_gpu_weights, host = ctx.omni_host_weights;
    for (size_t i = 0; i < planned.size(); ++i) {
        const size_t bytes = std::max(retained[i], planned[i]);
        if (ggml_backend_buft_is_host(ctx.backend_buft[i])) host = omni_vision_budget_add(host, bytes);
        else gpu = omni_vision_budget_add(gpu, bytes);
    }
    omni_vision_budget_require(gpu, host, ctx.omni_gpu_limit, ctx.omni_host_limit);
    std::fprintf(stdout, "OMNI_VISION_MEMORY_V1 {\"schema\":\"strata-vision-memory-v1\","
        "\"scope\":\"explicit_ggml_tensor_buffers\",\"gpu_bytes\":%zu,\"host_bytes\":%zu,"
        "\"gpu_limit\":%zu,\"host_limit\":%zu,\"phase\":\"before_graph_allocation\"}\n",
        gpu, host, ctx.omni_gpu_limit, ctx.omni_host_limit);
    std::fflush(stdout);
    if (!ggml_backend_sched_reserve(ctx.sched.get(), graph))
        throw std::runtime_error("vision admitted graph reserve failed");
    ggml_backend_sched_reset(ctx.sched.get());
}


int main(){
 auto backend=ggml_backend_cpu_init();if(!backend)return 2;
 ggml_backend_cpu_set_n_threads(backend,2);
 clip_ctx ctx;ctx.backend_ptrs={backend};ctx.backend_buft={ggml_backend_get_default_buffer_type(backend)};
 ctx.sched.value=ggml_backend_sched_new(ctx.backend_ptrs.data(),ctx.backend_buft.data(),1,128,false,true);
 for(int n:{16,1024,64}){
  ggml_backend_sched_reset(ctx.sched.get());
  ggml_init_params params{2*1024*1024,nullptr,true};auto meta=ggml_init(params);
  auto a=ggml_new_tensor_1d(meta,GGML_TYPE_F32,n);auto b=ggml_new_tensor_1d(meta,GGML_TYPE_F32,n);
  ggml_set_input(a);ggml_set_input(b);auto result=ggml_add(meta,a,b);ggml_set_output(result);
  auto g=ggml_new_graph_custom(meta,128,false);ggml_build_forward_expand(g,result);
  const size_t retained=ggml_backend_sched_get_buffer_size(ctx.sched.get(),backend);
  size_t planned=0;ggml_backend_sched_reserve_size(ctx.sched.get(),g,&planned);ggml_backend_sched_reset(ctx.sched.get());
  ctx.omni_host_limit=std::max(retained,planned);
  omni_vision_check_graph_budget(ctx,g);
  if(!ggml_backend_sched_alloc_graph(ctx.sched.get(),g))return 3;
  std::vector<float> x(n,1.25f),y(n,2.5f),z(n);
  ggml_backend_tensor_set(a,x.data(),0,n*sizeof(float));ggml_backend_tensor_set(b,y.data(),0,n*sizeof(float));
  if(ggml_backend_sched_graph_compute(ctx.sched.get(),g)!=GGML_STATUS_SUCCESS)return 4;
  ggml_backend_tensor_get(result,z.data(),0,n*sizeof(float));for(float v:z)if(v!=3.75f)return 5;
  std::printf("PASS real graph n=%d planned=%zu retained=%zu allocated=%zu\n",n,planned,retained,ggml_backend_sched_get_buffer_size(ctx.sched.get(),backend));
  ggml_backend_sched_reset(ctx.sched.get());
  ctx.omni_host_limit=0;bool refused=false;try{omni_vision_check_graph_budget(ctx,g);}catch(const std::runtime_error&){refused=true;}
  if(!refused)return 6;
  std::printf("PASS budget refusal n=%d\n",n);
  ggml_backend_sched_reset(ctx.sched.get());ggml_free(meta);
 }
 ggml_backend_sched_free(ctx.sched.get());ggml_backend_free(backend);return 0;
}
