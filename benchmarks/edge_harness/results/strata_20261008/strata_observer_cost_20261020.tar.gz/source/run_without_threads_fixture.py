"""Create only owned idle fixtures, measure read-only observer, then reap them."""
import json, pathlib, subprocess, sys, time
import psutil
HERE=pathlib.Path(__file__).resolve().parent
FLAGS=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0
if '--fixture' in sys.argv:
    children=[]
    try:
        for _ in range(16):
            children.append(subprocess.Popen([sys.executable,'-I','-B','-c','import time; time.sleep(180)'],creationflags=FLAGS))
        print(json.dumps(dict(pid=psutil.Process().pid,created=psutil.Process().create_time(),children=[c.pid for c in children])),flush=True)
        sys.stdin.readline()
    finally:
        for child in children:
            if child.poll() is None: child.terminate()
        for child in children: child.wait(timeout=10)
else:
    output=pathlib.Path(sys.argv[1])
    fixture=subprocess.Popen([sys.executable,'-I','-B',str(__file__),'--fixture'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,creationflags=FLAGS)
    identity=None
    try:
        identity=json.loads(fixture.stdout.readline())
        result=subprocess.run([sys.executable,'-I','-B',str(HERE/'diagnose_without_threads.py'),'--pid',str(identity['pid']),'--created',str(identity['created']),'--output',str(output),'--samples','12','--interval','2'],creationflags=FLAGS)
        if result.returncode: raise RuntimeError('Diagnostic failed: '+str(result.returncode))
    finally:
        if fixture.poll() is None:
            fixture.stdin.write('\n');fixture.stdin.flush()
        code=fixture.wait(timeout=30)
        if output.exists():
            (output/'fixture.json').write_text(json.dumps(dict(identity=identity,exit_code=code,scope='16 idle child interpreters; synthetic observer cost only; no model'),indent=2))
    print('Diagnostic complete; fixture exited',code)
