"""Bounded read-only observer cost diagnostic. No model or process control."""
import argparse
import hashlib
import json
import pathlib
import time
import psutil


def bound_process(pid, created):
    process = psutil.Process(pid)
    if abs(process.create_time() - created) > .001 or not process.is_running():
        raise RuntimeError('Target identity is no longer live')
    return process


def snapshot(process):
    with process.oneshot():
        return dict(pid=process.pid, created=process.create_time(), name=process.name(),
                    cpu=process.cpu_times()._asdict(), memory=process.memory_info()._asdict(),
                    threads=process.num_threads(), logical_io=process.io_counters()._asdict())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid', type=int, required=True)
    parser.add_argument('--created', type=float, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    parser.add_argument('--samples', type=int, default=10)
    parser.add_argument('--interval', type=float, default=2)
    args = parser.parse_args()
    if not 1 <= args.samples <= 60 or not 1 <= args.interval <= 60:
        parser.error('samples must be 1..60; interval must be 1..60 seconds')
    root = bound_process(args.pid, args.created)
    args.output.mkdir(parents=True, exist_ok=False)
    metadata = dict(schema='observer-component-cost-v1', root_pid=args.pid,
        root_created=args.created, samples=args.samples, interval_s=args.interval,
        script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        psutil_version=psutil.__version__, limits=[
            'Diagnostic itself adds CPU counter and serialization overhead',
            'Each component CPU interval includes all observer threads',
            'Logical I/O and system disk counters do not prove model physical SSD I/O',
            'Only surviving observed processes are covered; missing observations are errors',
            'Does not measure phase-file reading or production telemetry overhead'])
    (args.output/'config.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    observer = psutil.Process()
    def timed(label, operation, costs):
        cpu0 = observer.cpu_times(); start = time.perf_counter()
        try:
            return operation()
        finally:
            wall = time.perf_counter()-start
            cpu1 = observer.cpu_times()
            costs.append(dict(component=label, wall_s=wall,
                cpu_s=cpu1.user+cpu1.system-cpu0.user-cpu0.system))
    with (args.output/'samples.jsonl').open('x', encoding='utf-8') as stream:
        for seq in range(args.samples):
            tick = time.perf_counter(); costs = []; errors = []
            root = timed('root_identity', lambda: bound_process(args.pid,args.created), costs)
            children = timed('tree_discovery', lambda: root.children(recursive=True), costs)
            observations = []
            for process in [root]+children:
                try:
                    observations.append(timed('process_snapshot:'+str(process.pid),
                        lambda p=process: snapshot(p), costs))
                except (psutil.NoSuchProcess, psutil.AccessDenied) as error:
                    errors.append(dict(pid=process.pid, error=type(error).__name__))
            disk = timed('system_disk', psutil.disk_io_counters, costs)
            ram = timed('system_ram', psutil.virtual_memory, costs)
            own = timed('observer_snapshot', lambda: snapshot(observer), costs)
            row = dict(seq=seq, unix_time=time.time(), processes=observations,
                errors=errors, system_disk=disk._asdict() if disk else None,
                system_ram=ram._asdict(), observer=own, costs=costs)
            serialized = timed('serialization', lambda: json.dumps(row, separators=(',',':')), costs)
            # Costs list is shared with row; serialize again to include serialization cost.
            row['serialized_probe_bytes'] = len(serialized.encode())
            stream.write(json.dumps(row, separators=(',',':'))+'\n'); stream.flush()
            if seq+1 < args.samples:
                time.sleep(max(0,args.interval-(time.perf_counter()-tick)))
    (args.output/'completion.json').write_text(json.dumps(dict(status='completed',samples=args.samples)),encoding='utf-8')


if __name__ == '__main__':
    main()
