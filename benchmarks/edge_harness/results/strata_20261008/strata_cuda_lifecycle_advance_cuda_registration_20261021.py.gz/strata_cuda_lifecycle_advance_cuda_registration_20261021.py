from pathlib import Path
import hashlib,json,subprocess,time,psutil
root=Path('C:/Users/zhout/w2/strata-omni')
process=psutil.Process(222372)
if abs(process.create_time()-1792538808.318354)>0.001: raise RuntimeError('registration process identity changed')
print('waiting for exact running text registration',flush=True)
while True:
    try:
        code=process.wait(timeout=30)
        break
    except psutil.TimeoutExpired:
        print('text registration still running',flush=True)
if code not in (None,0):raise RuntimeError('text registration failed: '+str(code))
parent=root/'runs/q4-execution-cuda-v3-20261021'
receipt=json.loads((parent/'registration-attempt.json').read_bytes())
if receipt['status']!='registered_not_executed':raise RuntimeError('text registration did not succeed')
if hashlib.sha256((parent/'launch.json').read_bytes()).hexdigest()!=receipt['launch_sha256']:raise RuntimeError('text launch changed')
script=root/'prototypes/register_q4_cuda_v3_image_20261021.py'
if hashlib.sha256(script.read_bytes()).hexdigest()!='41215d6d545bd07044a3c4fca57ad970d3c3fc637ef8a54c089f181e1d4a8be9':raise RuntimeError('image registration producer changed')
print('text registration verified; starting CUDA image registration',flush=True)
with (root/'prototypes/cuda-v3-image-registration-20261021.log').open('x',encoding='utf-8') as log:
    child=subprocess.run(['C:/Users/zhout/w2/omni029venv/Scripts/python.exe','-I','-B','-X','utf8',str(script)],stdout=log,stderr=subprocess.STDOUT)
print('image registration exit '+str(child.returncode),flush=True)
raise SystemExit(child.returncode)
