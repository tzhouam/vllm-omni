import json,time
from pathlib import Path
import psutil
p=psutil.Process(222604); created=p.create_time();start=time.perf_counter();samples=0
out=Path('C:/Users/zhout/w2/strata-omni/prototypes/cuda-v3-static-verifier-resources-20261021.jsonl')
with out.open('x',encoding='utf-8') as f:
 f.write(json.dumps({'scope':'static verification only; sampling attached after import; earlier interval unobserved','pid':p.pid,'created':created})+'\n');f.flush()
 while True:
  try:
   if p.create_time()!=created: break
   with p.oneshot():
    row=dict(time=time.time(),cpu=p.cpu_times()._asdict(),memory=p.memory_info()._asdict(),logical_io=p.io_counters()._asdict())
   f.write(json.dumps(row)+'\n');f.flush();samples+=1
  except psutil.NoSuchProcess: break
  time.sleep(1)
 f.write(json.dumps({'terminal':True,'samples':samples,'wall_seconds':time.perf_counter()-start})+'\n')
print(samples)
