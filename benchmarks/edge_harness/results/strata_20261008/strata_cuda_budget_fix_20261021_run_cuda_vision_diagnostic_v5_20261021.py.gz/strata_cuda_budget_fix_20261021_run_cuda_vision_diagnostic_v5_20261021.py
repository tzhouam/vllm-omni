import json,hashlib,importlib.util,os,subprocess,time,threading,shutil
from pathlib import Path
import psutil
import pynvml as nv
r=Path(r'C:\Users\zhout\w2\strata-omni');repo=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge');prior=r/'runs/cuda-vision-real-v2-20261021';run=r/'runs/cuda-vision-diagnostic-v5-20261021';run.mkdir(exist_ok=False)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
cmp=load('cmp',repo/'benchmarks/edge_harness/compare_strata_sve.py');before=json.loads((prior/'receipt.json').read_text());assert before['phase']=='completed';cmd=before['argv'];cmd[0]=str(r/'runtime/vision-cuda-candidate-v2/strata-vision-v3.exe');exe=Path(cmd[0]);assert sha(exe)=='b7ee3ad280e0dc094283a335f6b97e22b48d5e374a0cd6f1e8f6fe589b0e1a27';assert sha(cmd[2])==before['projector_sha256'];assert sha(cmd[4])==before['verified_artifacts'][0]['sha256'];assert sha(prior/'input.png')==before['input.png_sha256'];shutil.copyfile(prior/'input.png',run/'input.png')
reference=r/'runs/q4-image-20g-gpu-lifecycle-tree1s-20261021/initial-approval_heading.sve';assert sha(reference)==before['comparison']['reference']['sha256']
rec={'schema':'omni-vision-diagnostic-v1','scope':'Sequential component diagnostics; only first text shard vocabulary and projector rehashed; full checkpoint binding inherited from preceding run','prior_receipt_sha256':sha(prior/'receipt.json'),'batch_size':1,'concurrency':1,'release_qualified':False,'cases':[]};nv.nvmlInit();handle=nv.nvmlDeviceGetHandleByIndex(0)
def save(): (run/'receipt.json').write_text(json.dumps(rec,indent=2))
for name,gpu,fa in [('gpu_workspace_refuse',True,'auto'),('host_workspace_refuse',True,'auto'),('gpu_weights_refuse',True,'auto')]:
 rec['phase']=name;save();assert psutil.virtual_memory().available>=8<<30;assert nv.nvmlDeviceGetMemoryInfo(handle).free>=10<<30
 argv=cmd.copy()
 if not gpu:argv.remove('--gpu')
 argv[-1]=fa
 env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='0',OMNI_VISION_EXPECTED_PCI_BUS_ID='00000000:64:00.0',OMNI_VISION_GGML_GPU_BUDGET_BYTES=str((1<<30) if name=="gpu_workspace_refuse" else ((1<<20) if name=="gpu_weights_refuse" else (8<<30))),OMNI_VISION_GGML_HOST_BUDGET_BYTES=str(0 if name=="host_workspace_refuse" else (4<<30)));env['PATH']=str(exe.parent)+os.pathsep+str(Path(os.environ['SystemRoot'])/'System32')
 row={'name':name,'argv':argv};t=time.monotonic();child=subprocess.Popen(argv,cwd=run,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW);row['pid']=child.pid;row['created']=psutil.Process(child.pid).create_time();stop=threading.Event()
 def sample():
  with (run/(name+'-resources.jsonl')).open('w') as f:
   while not stop.is_set():
    v={'unix':time.time()}
    try:
     p=psutil.Process(child.pid);v.update(gpu_used=nv.nvmlDeviceGetMemoryInfo(handle).used,gpu_power_mw=nv.nvmlDeviceGetPowerUsage(handle),host_available=psutil.virtual_memory().available,memory=p.memory_info()._asdict(),cpu=p.cpu_times()._asdict())
    except Exception as e:v['error']=type(e).__name__
    f.write(json.dumps(v)+'\n');f.flush();stop.wait(.5)
 th=threading.Thread(target=sample);th.start()
 try:
  out,err=child.communicate('ENC input.png '+name+'.sve\nQUIT\n',timeout=180)
 except subprocess.TimeoutExpired:
  child.kill();out,err=child.communicate();row['timeout']=True
 finally:stop.set();th.join()
 row['wall_s']=time.monotonic()-t;row['exit_code']=child.returncode;(run/(name+'-stdout.log')).write_text(out);(run/(name+'-stderr.log')).write_text(err)
 if child.returncode==0 and (run/(name+'.sve')).exists():row['comparison']=cmp.compare(reference,run/(name+'.sve'))
 rec['cases'].append(row);save();print(json.dumps(row),flush=True)
rec['phase']='completed';rec['files']={p.name:{'sha256':sha(p),'size_bytes':p.stat().st_size} for p in run.iterdir() if p.name!='receipt.json'};save()
