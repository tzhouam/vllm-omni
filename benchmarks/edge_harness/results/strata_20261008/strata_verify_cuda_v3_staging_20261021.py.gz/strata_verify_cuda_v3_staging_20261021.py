from pathlib import Path
import sys,json,time,hashlib
repo=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge');sys.path.insert(0,str(repo))
from vllm_omni.engine.backends import strata,strata_vision
root=Path('C:/Users/zhout/w2/strata-omni');runtime=root/'runtime/e39-v6-cuda-v3'
# Run only after the staging producer has completed and published its receipt.
receipt=json.loads((root/'prototypes/cuda-v3-full-staging-20261021.json').read_text())
assert strata_vision.digest(runtime/'members.json')==receipt['members_sha256']
start=time.perf_counter();files={p.resolve() for p in runtime.rglob('*') if p.is_file()}
modules=strata._load_execution_adapters(runtime,files)
identity=modules['strata_exec_runtime'].verify_combined_runtime('descriptor.json',runtime)
build=json.loads((runtime/'cuda-vision-build/build.json').read_text())
reviewed,_=strata_vision.reviewed_vision_build('cuda',strata_vision.digest(runtime/'vision-cuda/strata-vision.exe'))
for row in build['evidence_files']:
 assert strata_vision.digest(runtime/row['path'])==row['sha256']
 if row['role'] in reviewed: assert reviewed[row['role']]==row['sha256']
assert set(reviewed)<={r['role'] for r in build['evidence_files']}
assert strata_vision.scan_pe_closure(runtime/'vision-cuda/strata-vision.exe',runtime,files,max_file_bytes=512<<20)==build['pe_dependency_closure']
report=dict(schema='omni-strata-cuda-staged-runtime-verification-v1',identity=identity,elapsed_seconds=time.perf_counter()-start,vision_build_sha256=strata_vision.digest(runtime/'cuda-vision-build/build.json'),scope='production static verifier plus CUDA source and PE closure; no live model load',passed=True)
(root/'prototypes/cuda-v3-full-verify-20261021.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({'passed':True,'seconds':report['elapsed_seconds'],'identity':identity['identity_sha256']}))
