"""Small real-file parity and executor-lifetime tests; no model execution."""
import hashlib
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

HERE = Path(__file__).parent
REPO = Path(r"\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge")
sys.path[:0] = [str(HERE), str(REPO)]
from bounded_verify import verify_bounded
from vllm_omni.engine.weight_tiers import ArtifactFile, ArtifactManifest


class VerifyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="omni-verify-fixture-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.files = []
        for i in range(12):
            data = (f"fixture-{i}" * (i + 1)).encode()
            name = f"member-{i:02d}.bin"
            (self.root / name).write_bytes(data)
            self.files.append(ArtifactFile(name, len(data), hashlib.sha256(data).hexdigest()))
        self.manifest = ArtifactManifest("fixture/runtime", "fixture-revision-1", "test", tuple(self.files))

    def test_full_real_file_parity_and_order(self):
        expected = self.manifest.verify(self.root)
        for workers in (1, 2, 4):
            self.assertEqual(verify_bounded(self.manifest, self.root, workers=workers), expected)

    def assert_same_failure(self):
        with self.assertRaises((ValueError, FileNotFoundError)) as serial:
            self.manifest.verify(self.root)
        with self.assertRaises(type(serial.exception)) as parallel:
            verify_bounded(self.manifest, self.root)
        self.assertEqual(str(parallel.exception), str(serial.exception))

    def test_missing_file(self):
        (self.root / self.files[3].path).unlink()
        self.assert_same_failure()

    def test_changed_size(self):
        (self.root / self.files[2].path).write_bytes(b"short")
        self.assert_same_failure()

    def test_same_size_corruption(self):
        p = self.root / self.files[5].path
        p.write_bytes(b"x" * p.stat().st_size)
        self.assert_same_failure()

    def test_multiple_failures_preserve_manifest_error_order(self):
        for i in (1, 2, 3):
            p = self.root / self.files[i].path
            p.write_bytes(b"x" * p.stat().st_size)
        self.assert_same_failure()

    def test_no_cached_digest(self):
        verify_bounded(self.manifest, self.root)
        p = self.root / self.files[0].path
        p.write_bytes(b"x" * p.stat().st_size)
        self.assert_same_failure()

    def test_worker_bound_validation(self):
        for workers in (0, 5, -1, True, 1.5, "4"):
            with self.subTest(workers=workers), self.assertRaises(ValueError):
                verify_bounded(self.manifest, self.root, workers=workers)

    def test_manifest_validation_stays_production_owned(self):
        for path in ("../escape", "x\\y", "C:/bad", "CON", "a/../b"):
            with self.subTest(path=path), self.assertRaises(ValueError):
                ArtifactFile(path, 0, "0" * 64)
        with self.assertRaises(TypeError):
            verify_bounded({}, self.root)

    def test_started_workers_drained_before_failure_returns(self):
        rendezvous = threading.Barrier(4)
        release = threading.Event()
        returned = threading.Event()
        completed = []
        errors = []
        def worker(root, item):
            rendezvous.wait(timeout=5)
            if item.path == self.files[0].path:
                raise ValueError("first failure")
            if not release.wait(5):
                raise RuntimeError("test release timed out")
            completed.append(item.path)
            return root / item.path
        def invoke():
            try:
                verify_bounded(self.manifest, self.root)
            except Exception as error:
                errors.append(error)
            finally:
                returned.set()
        with patch("bounded_verify._verify_file", worker):
            thread = threading.Thread(target=invoke)
            thread.start()
            try:
                self.assertFalse(returned.wait(.1))
            finally:
                release.set()
                thread.join(10)
            self.assertFalse(thread.is_alive())
            self.assertEqual(len(completed), 3)
            self.assertEqual([str(e) for e in errors], ["first failure"])
        self.assertFalse(any(t.name.startswith("artifact-check-prototype") for t in threading.enumerate()))

    def test_pending_futures_are_bounded(self):
        state = {"pending": 0, "peak": 0}
        class Future:
            def __init__(self, function, args):
                self.function, self.args = function, args
            def result(self):
                state["pending"] -= 1
                return self.function(*self.args)
            def cancel(self):
                return True
        class Executor:
            def __init__(self, **kwargs):
                pass
            def submit(self, function, *args):
                state["pending"] += 1
                state["peak"] = max(state["peak"], state["pending"])
                return Future(function, args)
            def shutdown(self, **kwargs):
                self.assertion = kwargs
        with patch("bounded_verify.ThreadPoolExecutor", Executor):
            self.assertEqual(verify_bounded(self.manifest, self.root), self.manifest.verify(self.root))
        self.assertEqual(state, {"pending": 0, "peak": 4})


if __name__ == "__main__":
    unittest.main(verbosity=2)
