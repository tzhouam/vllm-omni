"""Experimental bounded parallel verification; never used by a serving route.

All path, byte-count and full-hash checks match ArtifactManifest.verify. The
executor retains at most `workers` pending futures and preserves manifest order.
It drains started workers before returning or raising. No digest cache is used.
"""
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from vllm_omni.engine.weight_tiers import ArtifactManifest, _local_path, sha256_file


def _verify_file(root, item):
    path = _local_path(root, item.path)
    if not path.is_file():
        raise FileNotFoundError(f"artifact file missing: {item.path}")
    if path.stat().st_size != item.size_bytes:
        raise ValueError(f"artifact size mismatch: {item.path}")
    if sha256_file(path) != item.sha256:
        raise ValueError(f"artifact SHA256 mismatch: {item.path}")
    return path


def verify_bounded(manifest, root, *, workers=4):
    if not isinstance(manifest, ArtifactManifest):
        raise TypeError("typed production ArtifactManifest required")
    if type(workers) is not int or not 1 <= workers <= 4:
        raise ValueError("workers must be an integer from 1 to 4")
    root = Path(root).resolve()
    items = iter(manifest.files)
    pending, verified = deque(), []
    executor = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="artifact-check-prototype")
    try:
        for item in items:
            pending.append(executor.submit(_verify_file, root, item))
            if len(pending) == workers:
                break
        while pending:
            verified.append(pending.popleft().result())
            item = next(items, None)
            if item is not None:
                pending.append(executor.submit(_verify_file, root, item))
        return tuple(verified)
    finally:
        for future in pending:
            future.cancel()
        executor.shutdown(wait=True, cancel_futures=True)
