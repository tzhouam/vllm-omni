from pathlib import Path
import importlib.util,shutil,json,time
repo=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge')
root=Path('C:/Users/zhout/w2/strata-omni')
spec=importlib.util.spec_from_file_location('vision_bundle',repo/'vllm_omni/engine/backends/strata_vision.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
start=time.perf_counter();out=root/'runtime/vision-cuda-v3-reviewed';out.mkdir(exist_ok=False)
bin_dir=out/'vision-cuda';bin_dir.mkdir(); proof_dir=out/'vision-build';proof_dir.mkdir()
source=json.loads((root/'prototypes/cuda-v3-provenance-recheck-20261021.json').read_text())
proof=[]
for row in source['files']:
 src=Path(row['path']); dst=proof_dir/(row['role']+src.suffix)
 shutil.copyfile(src,dst)
 assert v.digest(dst)==v.REVIEWED_CUDA_VISION_EVIDENCE[row['role']]
 proof.append(dict(role=row['role'],path=dst.relative_to(out).as_posix(),sha256=v.digest(dst)))
extra={
'configure_log':root/'runs/cuda-vision-build-v1-20261021/configure.log',
'build_log':root/'runs/cuda-vision-build-v3-20261021/build.log',
'initial_build_log':root/'runs/cuda-vision-build-v1-20261021/build.log',
'initial_build_receipt':root/'runs/cuda-vision-build-v1-20261021/receipt.json',
'final_build_receipt':root/'runs/cuda-vision-build-v3-20261021/receipt.json',
'cmake_cache':root/'bv-gpu-v1/CMakeCache.txt',
}
for role,src in extra.items():
 dst=proof_dir/(role+src.suffix);shutil.copyfile(src,dst);proof.append(dict(role=role,path=dst.relative_to(out).as_posix(),sha256=v.digest(dst)))
exe=bin_dir/'strata-vision.exe';shutil.copyfile(source['encoder']['path'],exe)
v.reviewed_vision_build('cuda',v.digest(exe))
deps=[]
for name,sha in {
'cublas64_13.dll':'1119dbca0a808e0c8850bb4221e330daf0b5ddb348d62d37b6ac533854723df9',
'cublasLt64_13.dll':'0f5bc315fef706b5626248ebd74e8a48a9e82fa2f0cad38330f5f70984913107',
}.items():
 dst=bin_dir/name;shutil.copyfile(root/'runtime/vision-cuda-candidate-v2'/name,dst);assert v.digest(dst)==sha
 deps.append(dict(path=dst.relative_to(out).as_posix(),sha256=sha,size_bytes=dst.stat().st_size))
closure=v.scan_pe_closure(exe,out,set(out.rglob('*')),max_file_bytes=512<<20)
assert {r['path'] for r in closure['files']}=={exe.relative_to(out).as_posix()}|{r['path'] for r in deps}
receipt=json.loads(extra['final_build_receipt'].read_text());assert receipt['exit_code']==0 and receipt['encoder_sha256']==v.digest(exe)
build=dict(schema='omni-strata-vision-build-v1',base_revision=v.BASE_REVISION,dependency_revision=v.DEPENDENCY_REVISION,dependency_tree=v.DEPENDENCY_TREE,encoder_sha256=v.digest(exe),native_observation_schema='strata-vision-backend-v1',configure_exit_code=0,build_exit_code=0,cmake_options=dict(STRATA_VISION_CUDA='ON',STRATA_PORTABLE='ON',CMAKE_BUILD_TYPE='Release',CMAKE_CUDA_ARCHITECTURES='120'),evidence_files=proof,native_dependency_files=deps,pe_dependency_closure=closure)
(proof_dir/'build.json').write_text(json.dumps(build,indent=2),encoding='utf-8')
files=[dict(path=p.relative_to(out).as_posix(),sha256=v.digest(p),size_bytes=p.stat().st_size) for p in sorted(out.rglob('*')) if p.is_file()]
report=dict(schema='omni-isolated-vision-bundle-v1',root=str(out),files=files,file_count=len(files),size_bytes=sum(x['size_bytes'] for x in files),wall_seconds=time.perf_counter()-start,pe_closure=closure,scope='isolated encoder bundle only; not complete language runtime or live qualification',neural_run=False)
(root/'prototypes/cuda-v3-isolated-bundle-20261021.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['root','file_count','size_bytes','wall_seconds','scope']}))
