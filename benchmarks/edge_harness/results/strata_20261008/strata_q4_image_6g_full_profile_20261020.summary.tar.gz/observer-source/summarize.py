"""Summarize an immutable sampled prefix without claiming physical I/O attribution."""
import argparse, hashlib, json, pathlib


def summarize(lines):
    phases = {}
    previous = None
    count = 0
    max_gap = 0.0
    errors = 0
    transitions = 0
    for line in lines:
        row = json.loads(line)
        if row['seq'] != count:
            raise ValueError('Missing or repeated sample sequence')
        phase = (row.get('latest_phase') or {}).get('phase', 'unknown')
        group = phases.setdefault(phase, dict(samples=0, process_peak_rss_bytes={},
            process_peak_private_bytes={}, observed_cpu_seconds=0., logical_read_bytes=0,
            logical_write_bytes=0, observer_collection_wall_seconds=0.,
            measured_interval_seconds=0., first_timestamp=row['timestamp']))
        group['samples'] += 1
        group['last_timestamp'] = row['timestamp']
        group['observer_collection_wall_seconds'] += row['collection_wall_seconds']
        eligible = False
        if previous is not None:
            gap = row['elapsed_seconds'] - previous['elapsed_seconds']
            if gap <= 0:
                raise ValueError('Non-monotonic sample time')
            max_gap = max(max_gap, gap)
            prior_phase = (previous.get('latest_phase') or {}).get('phase', 'unknown')
            eligible = phase == prior_phase
            if eligible:
                group['measured_interval_seconds'] += gap
            else:
                transitions += 1
        for process in row['processes']:
            if 'observation_error' in process:
                errors += 1
                continue
            key = str(process['pid']) + '@' + str(process['created'])
            memory = process['memory']
            group['process_peak_rss_bytes'][key] = max(group['process_peak_rss_bytes'].get(key,0),memory['rss'])
            if 'private' in memory:
                group['process_peak_private_bytes'][key] = max(group['process_peak_private_bytes'].get(key,0),memory['private'])
            if eligible and 'logical_io_delta' in process:
                deltas = process['logical_io_delta']
                if min(deltas.values()) < 0 or process['cpu_seconds_delta'] < 0:
                    raise ValueError('Counter decreased within process identity')
                group['observed_cpu_seconds'] += process['cpu_seconds_delta']
                group['logical_read_bytes'] += deltas['read_bytes']
                group['logical_write_bytes'] += deltas['write_bytes']
        previous = row
        count += 1
    if not count:
        raise ValueError('No complete samples')
    return dict(samples=count, max_gap_seconds=max_gap, observation_errors=errors,
        excluded_phase_transition_intervals=transitions, phases=phases,
        limits=['Partial sampled coverage; not full request or startup latency',
                'Process peaks are separate and not additive physical RAM',
                'Logical I/O is not physical SSD I/O',
                'First samples, phase transition deltas and missing observations are excluded',
                'Phase totals cover observed processes; exited short-lived processes may be missed'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=pathlib.Path)
    parser.add_argument('output', type=pathlib.Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    prefix = raw[:raw.rfind(b'\n')+1]
    result = summarize(prefix.splitlines())
    result['source_prefix_sha256'] = hashlib.sha256(prefix).hexdigest()
    result['source_prefix_bytes'] = len(prefix)
    result['source_path'] = str(args.input)
    with args.output.open('x', encoding='utf-8') as out:
        json.dump(result,out,indent=2)
        out.write('\n')


if __name__ == '__main__':
    main()
