import hashlib, json, math, time
from pathlib import Path
root = Path(r'C:\Users\zhout\w2\strata-omni')
run = root / 'runs/q4-image-agent-full-20g-tree1s-20261021'
out = root / 'runs/q4-image-agent-full-20g-tree1s-20261021-resource-summary.json'
receipt_path = run / 'receipt.json'
receipt_raw = receipt_path.read_bytes()
assert hashlib.sha256(receipt_raw).hexdigest() == 'f4d863fd76033fd36bdb06bd7325dbb2fad1163c9310dd6e86db9eaa4ace30f7'
receipt = json.loads(receipt_raw)
assert receipt['phase'] == 'completed'
expected = receipt['raw_files']['telemetry.jsonl']
source = run / 'telemetry.jsonl'
assert source.stat().st_size == expected['size_bytes']
sha = hashlib.sha256()
peaks, minima, counts = {}, {}, {}
rows = 0
first = last = None
def observe(label, value, minimum=False):
    if value is None:
        return
    assert type(value) in (int, float) and math.isfinite(value), label
    counts[label] = counts.get(label, 0) + 1
    peaks[label] = max(peaks.get(label, value), value)
    if minimum:
        minima[label] = min(minima.get(label, value), value)
with source.open('rb') as stream:
    for raw in stream:
        sha.update(raw)
        sample = json.loads(raw)
        stamp = sample['unix']
        if first is None:
            first = stamp
        assert last is None or stamp >= last
        last = stamp
        rows += 1
        host = sample.get('host') or {}
        for key in ('available_ram_bytes', 'used_ram_bytes', 'process_tree_rss_sum_bytes', 'swap_used_bytes'):
            observe('host.' + key, host.get(key), key == 'available_ram_bytes')
        for gpu in sample.get('gpus', []):
            label = 'gpu.' + str(gpu.get('uuid')) + '.'
            for key in ('used_vram_bytes', 'power_mw', 'temperature_c'):
                observe(label + key, gpu.get(key))
        process_gpu = sample.get('process_gpu') or {}
        for key in ('local_current_usage_bytes', 'nonlocal_current_usage_bytes'):
            observe('process_gpu.' + key, process_gpu.get(key))
assert rows and sha.hexdigest() == expected['sha256']
result = dict(schema='omni-closed-run-resource-summary-v1', source=str(source), source_sha256=sha.hexdigest(),
              source_size_bytes=source.stat().st_size, receipt_sha256=hashlib.sha256(receipt_raw).hexdigest(),
              samples=rows, first_unix=first, last_unix=last, observed_span_s=last-first,
              peak_observed_values=peaks, minimum_observed_values=minima, valid_sample_counts=counts,
              limitations=['Sampled peaks, not guaranteed instantaneous maxima',
              'Whole-system RAM and GPU usage include other applications',
              'Process RSS sum double-counts shared pages; not physical RAM attribution',
              'System swap usage does not prove model paging',
              'WDDM nonlocal usage is shared host RAM, not proof of GPU spill',
              'GPU power is not whole-device power; no physical SSD attribution',
              'Fixed screenshot task family; no default route qualification'],
              producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with out.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
