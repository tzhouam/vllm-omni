"""Post-profile verifier experiment. Never invoked by the serving backend."""
import argparse, hashlib, json, pathlib, sys, time
import psutil
HERE=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge')
sys.path[:0]=[str(HERE),str(REPO)]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def guard(pid, created):
    try:
        p=psutil.Process(pid)
        if abs(p.create_time()-created)<0.001 and p.is_running():
            raise RuntimeError('Bound profiling process is still running; benchmark refused')
    except psutil.NoSuchProcess:
        pass


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest',type=pathlib.Path,required=True)
    ap.add_argument('--manifest-file-sha256',required=True)
    ap.add_argument('--root',type=pathlib.Path,required=True)
    ap.add_argument('--output',type=pathlib.Path,required=True)
    ap.add_argument('--profile-pid',type=int,required=True)
    ap.add_argument('--profile-created',type=float,required=True)
    a=ap.parse_args()
    guard(a.profile_pid,a.profile_created)
    from bounded_verify import verify_bounded
    from vllm_omni.engine.weight_tiers import ArtifactManifest
    if sha(a.manifest)!=a.manifest_file_sha256:
        raise ValueError('Manifest file identity mismatch')
    m=ArtifactManifest.from_dict(json.loads(a.manifest.read_text(encoding='utf-8')))
    sources=[pathlib.Path(__file__),HERE/'bounded_verify.py',REPO/'vllm_omni/engine/weight_tiers.py']
    bound={str(p):sha(p) for p in sources}
    a.output.mkdir(parents=True,exist_ok=False)
    proc=psutil.Process()
    rows=[]
    # Reversed pairs reduce simple run-order bias; no cold-cache assertion.
    sequence=[0,2,4,0,4,2,0,2,4,0,4,2]
    metadata=dict(manifest_sha256=m.manifest_sha256,manifest_file_sha256=a.manifest_file_sha256,
        root=str(a.root.resolve()),files=len(m.files),bytes=m.total_size_bytes,sources=bound,
        sequence=sequence,zero_means='production serial verify',cache_condition='uncontrolled; no cache flush',
        scope='artifact verification microbenchmark only, not whole startup or Agent latency',
        full_content_hash_required=True,digest_cache=False)
    (a.output/'config.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    with (a.output/'samples.jsonl').open('x',encoding='utf-8') as f:
        for index,workers in enumerate(sequence):
            guard(a.profile_pid,a.profile_created)
            cpu0=proc.cpu_times();io0=proc.io_counters();start=time.perf_counter()
            verified=m.verify(a.root) if workers==0 else verify_bounded(m,a.root,workers=workers)
            elapsed=time.perf_counter()-start
            cpu1=proc.cpu_times();io1=proc.io_counters()
            if verified != tuple((a.root/item.path).resolve() for item in m.files):
                raise RuntimeError('Verification order/identity differs')
            row=dict(index=index,workers=workers,elapsed_s=elapsed,
                cpu_seconds=cpu1.user+cpu1.system-cpu0.user-cpu0.system,
                process_logical_read_bytes=io1.read_bytes-io0.read_bytes,
                rss_after_bytes=proc.memory_info().rss,host_available_bytes=psutil.virtual_memory().available,
                verified_files=len(verified))
            f.write(json.dumps(row)+'\n');f.flush();rows.append(row)
    if bound!={str(p):sha(p) for p in sources} or sha(a.manifest)!=a.manifest_file_sha256:
        raise RuntimeError('Source or manifest changed')
    (a.output/'completion.json').write_text(json.dumps(dict(status='completed',samples=len(rows),
        source_stable=True,production_integrated=False),indent=2),encoding='utf-8')


if __name__=='__main__':
    main()

