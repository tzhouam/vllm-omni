"""Private pure-contract tests; synthetic records are never neural evidence."""

from __future__ import annotations

import asyncio
import copy
import hashlib
import importlib.util
import json
import struct
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


runner = load("private_image_lifecycle_candidate", ROOT / "run_strata_image_lifecycle.py")
io = load("private_image_actual_io_contract", runner.REPO / "vllm_omni/engine/backends/strata_io.py")


def test_import_has_no_engine_or_model_side_effects():
    assert not hasattr(runner, "driver")
    assert callable(runner.runtime_api)


@pytest.mark.parametrize("raw", ['{"a":1,"a":2}', '{"a":NaN}', "[]"])
def test_metadata_duplicate_nonfinite_and_nonobject_refuse(tmp_path, raw):
    path = tmp_path / "bad.json"
    path.write_text(raw)
    with pytest.raises(ValueError):
        runner.object_file(path)


def test_exclusive_outputs_are_preserved(tmp_path):
    path = tmp_path / "proof.json"
    runner.save(path, {"original": True}, exclusive=True)
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        runner.save(path, {"replace": True}, exclusive=True)
    assert path.read_bytes() == before


@pytest.fixture
def native():
    identity = {
        "schema": "omni-strata-observed-runtime-v1",
        "base_revision": io.BASE_REVISION,
        "dependency_revision": io.DEPENDENCY_REVISION,
        "patch_sha256": io.PATCH_SHA256,
        "native_io_schema": "strata-omni-io-v1",
        "three_tier_memory_qualified": False,
    }
    identity["identity_sha256"] = runner.canonical(identity)
    observer = io.StrataIoObserver("a" * 32, "generation-a", 123, 456, identity)
    observer.begin("request-a", 1)

    def emit(kind, payload):
        frame = {
            "schema": io.FRAME_SCHEMA,
            "generation": "generation-a",
            "pid": 123,
            "creation_filetime_100ns": 456,
            "dispatch_seq": 1,
            "kind": kind,
            "payload": payload,
        }
        assert observer.ingest(io.PREFIX + "a" * 32 + " " + json.dumps(frame) + "\n")

    emit("dispatch", {"command": "GENI"})
    for index, phase in enumerate(io.PHASES):
        row = {
            "schema": "strata-omni-io-v1",
            "request_seq": 1,
            "phase": phase,
            "scope": io.SCOPE,
            "qpc": 100 + index,
            "qpc_hz": 1000,
            "physical_ssd_read_bytes": None,
        }
        for group, ints, floats, bools in (
            ("expert", io.EXPERT_INTS, io.EXPERT_FLOATS, io.EXPERT_BOOLS),
            ("ple", io.PLE_INTS, io.PLE_FLOATS, io.PLE_BOOLS),
        ):
            row[group] = {key: 0 for key in ints} | {key: float(index) for key in floats} | {key: True for key in bools}
        row["expert"]["logical_file_bytes"] = index * 128
        emit("snapshot", row)
    emit("terminal", {"finish": "stop"})
    report = observer.finish("request-a", 1, completed=True)
    plan = {
        "worker_generation": "generation-a",
        "selected_native_module_audit_at_load": {"pid": 123, "creation_filetime_100ns": 456},
        "observation_runtime": identity,
    }
    return report, plan


def test_native_report_from_real_observer_passes_scoped_boundary_check(native):
    report, plan = native
    runner.validate_native(io, report, plan, "request-a", 1, 1)


@pytest.mark.parametrize(
    "mutation",
    [
        "owner",
        "generation",
        "seq",
        "physical",
        "scope",
        "stop",
        "phase",
        "counter",
        "interval",
        "error",
        "reason",
        "atomic",
    ],
)
def test_native_identity_phase_counter_and_scope_tampering_refuses(native, mutation):
    report, plan = native
    if mutation == "owner":
        report["native_pid"] += 1
    elif mutation == "generation":
        report["generation"] = "other"
    elif mutation == "seq":
        report["native_request_seq"] = 2
    elif mutation == "physical":
        report["physical_ssd_read_bytes"] = 1
    elif mutation == "scope":
        report["loading_covered"] = True
    elif mutation == "stop":
        report["native_terminal"] = "length"
    elif mutation == "phase":
        report["raw_snapshots"][1]["phase"] = "request_end"
    elif mutation == "counter":
        report["raw_snapshots"][1]["expert"]["logical_file_bytes"] = 9999
    elif mutation == "interval":
        report["intervals"]["decode"]["boundary_wall_s"] += 1
    elif mutation == "error":
        report["raw_snapshots"][2]["expert"][next(iter(io.ERROR_KEYS["expert"]))] = 1
    elif mutation == "reason":
        report["reasons"] = ["unverified"]
    elif mutation == "atomic":
        report["snapshot_consistency"] = "global_atomic"
    with pytest.raises(ValueError):
        runner.validate_native(io, report, plan, "request-a", 1, 1)


def active_client(*, end=None, dispatch=None, retired=False):
    owner = {"pid": 1, "creation_filetime_100ns": 2}
    backend = {"device_type": "CPU"}
    active = {
        "request_id": "request",
        "epoch": 3,
        "image_sha256": runner.IMAGE_SHA,
        "native_encoder_request_seq": 3,
        "start": {"image_sha256": runner.IMAGE_SHA, "input_bytes": 20},
        "end": end,
        "dispatch": dispatch,
    }
    observer = SimpleNamespace(_lock=threading.RLock(), active=active, identity=owner, backend=backend, retired=retired)
    return SimpleNamespace(
        _encoder_observer=observer,
        execution_plan={
            "owned_encoder_at_load": owner,
            "encoder_backend_selection_at_load": backend,
            "worker_generation": "generation",
        },
    )


def test_encoder_window_requires_actual_started_not_completed_phase():
    client = active_client()
    assert runner.encoder_window(client, "request", runner.IMAGE_SHA, 3)["encode_end"] is None
    client._encoder_observer.active["start"] = None
    assert runner.encoder_window(client, "request", runner.IMAGE_SHA, 3) is None


@pytest.mark.parametrize("mutation", ["end", "dispatch", "retired", "request", "image", "seq", "owner"])
def test_encoder_window_race_or_spoof_refuses(mutation):
    client = active_client()
    if mutation == "end":
        client._encoder_observer.active["end"] = {}
    elif mutation == "dispatch":
        client._encoder_observer.active["dispatch"] = {}
    elif mutation == "retired":
        client._encoder_observer.retired = True
    elif mutation == "request":
        client._encoder_observer.active["request_id"] = "foreign"
    elif mutation == "image":
        client._encoder_observer.active["image_sha256"] = "0" * 64
    elif mutation == "seq":
        client._encoder_observer.active["native_encoder_request_seq"] = 4
    elif mutation == "owner":
        client._encoder_observer.identity = {"pid": 99, "creation_filetime_100ns": 2}
    with pytest.raises(ValueError):
        runner.encoder_window(client, "request", runner.IMAGE_SHA, 3)


@pytest.mark.parametrize("which", ["owner", "quarantined", "reserved", "bool"])
def test_unknown_or_retained_ledger_cannot_admit_recovery(which):
    ledger = {"owners": [], "quarantined": [], "reserved": {"host_ram": 0}}
    if which == "owner":
        ledger["owners"] = [{}]
    elif which == "quarantined":
        ledger["quarantined"] = [{}]
    elif which == "reserved":
        ledger["reserved"]["host_ram"] = 1
    elif which == "bool":
        ledger["reserved"]["host_ram"] = False
    with pytest.raises(ValueError):
        runner.require_empty_ledger(ledger)


@pytest.mark.parametrize("mutation", [None, "hash", "missing", "oversize"])
def test_sve_capture_persists_only_bounded_same_hash_output(tmp_path, mutation):
    scratch = tmp_path / "vision-scratch"
    scratch.mkdir()
    data = struct.pack("<5i", 0x31455653, 2, 1, 2, 4) + b"\0" * 32
    path = scratch / "encoded.sve"
    path.write_bytes(data)
    result = {"sve_bytes": len(data), "sve_sha256": runner.file_hash(path), "image_tokens": 2, "nx": 1, "ny": 2}
    client = SimpleNamespace(
        _temporary=SimpleNamespace(name=str(tmp_path)),
        execution_plan={"image_route": {"bounds_and_declared_budgets": {"embedding_width": 4, "max_image_tokens": 2}}},
    )
    if mutation == "hash":
        result["sve_sha256"] = "0" * 64
    elif mutation == "missing":
        path.unlink()
    elif mutation == "oversize":
        result["sve_bytes"] = 1 << 30
    if mutation:
        with pytest.raises(ValueError):
            runner.capture_sve(client, {"encode_result": result}, tmp_path / "saved.sve")
    else:
        saved = runner.capture_sve(client, {"encode_result": result}, tmp_path / "saved.sve")
        assert saved["sha256"] == result["sve_sha256"]
        assert (tmp_path / "saved.sve").read_bytes() == data


@pytest.mark.parametrize("race,retired", [(False, True), (True, True), (False, False)])
def test_cancel_encoder_requires_incomplete_phase_and_authoritative_both_role_retirement(monkeypatch, race, retired):
    request = {}

    async def submit(rid, state, prompt):
        request["id"] = rid

    client = active_client()
    image = {
        "status": "incomplete",
        "epoch": 3,
        "generation": "generation",
        "owned_encoder": client.execution_plan["owned_encoder_at_load"],
        "input_sha256": runner.IMAGE_SHA,
        "native_encoder_request_seq": 3,
        "encode_result": {} if race else None,
        "language_dispatch": None,
        "reasons": ["cancelled"],
        "physical_ssd_read_bytes": None,
        "release_qualified": False,
    }
    native = {
        "status": "incomplete",
        "epoch": 3,
        "generation": "generation",
        "native_request_seq": None,
        "raw_snapshots": [],
        "native_terminal": None,
        "physical_ssd_read_bytes": None,
        "loading_covered": False,
    }
    client.last_image_observation = lambda: dict(image, request_id=request["id"])
    client.last_io_observation = lambda: dict(native, request_id=request["id"])

    async def cancel(rid):
        return {"drained": True}

    driver = SimpleNamespace(
        pool=SimpleNamespace(submit_initial=submit),
        cancel=cancel,
        resource_ledger=SimpleNamespace(
            snapshot=lambda: {"owners": [], "quarantined": [], "reserved": {"host_ram": 0}}
        ),
    )

    def window(_client, rid, *_):
        return {
            "request_id": rid,
            "epoch": 3,
            "generation": "generation",
            "owned_encoder": client.execution_plan["owned_encoder_at_load"],
            "observed_monotonic_s": 0,
        }

    monkeypatch.setattr(runner, "encoder_window", window)
    owners = {
        role: SimpleNamespace(state=lambda: "alive", close_retired=lambda: retired) for role in ("encoder", "language")
    }
    api = SimpleNamespace(profile=SimpleNamespace(require_drained_ledger=runner.require_empty_ledger))
    if race or not retired:
        with pytest.raises(ValueError):
            asyncio.run(runner.cancel_encoder(driver, client, {}, api, 3, owners))
    else:
        record = asyncio.run(runner.cancel_encoder(driver, client, {}, api, 3, owners))
        assert record["status"] == "cancelled_during_observed_encoder_phase"
        assert record["cancel_call_started_monotonic_s"] <= record["cancel_call_finished_monotonic_s"]


@pytest.fixture
def closed_lifecycle(tmp_path, monkeypatch, native):
    """Small closed synthetic evidence, never a model/image execution claim."""
    root = tmp_path / "evidence"
    root.mkdir()
    launch = tmp_path / "launch.json"
    runner.save(launch, {"synthetic": True}, exclusive=True)
    (root / "effective-launch.json").write_bytes(launch.read_bytes())
    runner.save(root / "reference.json", {"synthetic": True}, exclusive=True)
    (root / "input.png").write_bytes(b"synthetic-image-not-neural-evidence")
    image_sha = runner.file_hash(root / "input.png")
    monkeypatch.setattr(runner, "IMAGE_SHA", image_sha)
    source = {"synthetic-owned-source": "1" * 64}
    monkeypatch.setattr(runner, "source_identity", lambda: source)
    native_report, base_plan = native
    image_identity = {"synthetic": True}
    image_identity["identity_sha256"] = runner.canonical(image_identity)
    controls = {"image_route": image_identity}
    receipt = {
        "schema": runner.SCHEMA,
        "phase": "completed",
        "script_sha256": runner.file_hash(runner.__file__),
        "batch_size": 1,
        "concurrency": 1,
        "physical_ssd_read_bytes": None,
        "release_qualified": False,
        "three_tier_memory_qualified": False,
        "telemetry": {"sampling_thread_stopped": True},
        "source_before": source,
        "source_after": source,
        "initial_exact_roles_retired": {"encoder": True, "language": True},
        "launch_file": str(launch),
        "input_identity": {
            "launch_file_sha256": runner.file_hash(launch),
            "reference_file_sha256": runner.file_hash(root / "reference.json"),
        },
        "ledger_final": {"owners": [], "quarantined": [], "reserved": {"host_ram": 0}},
        "loaded_python_runtime_identity": {"synthetic": True},
        "loaded_python_runtime_sha256": runner.canonical({"synthetic": True}),
        "requests": [],
    }
    for key in (
        "resource_drain_verified",
        "source_stable",
        "input_stable",
        "encoder_phase_cancel_passed",
        "fresh_generation_image_recovery_passed",
    ):
        receipt[key] = True
    plans = {}
    for phase, offset in (("initial", 0), ("recovery", 10)):
        plan = plans[phase] = copy.deepcopy(base_plan)
        plan.update(
            backend=runner.BACKEND,
            worker_generation="generation-" + phase,
            route_controls=controls,
            route_controls_sha256=runner.canonical(controls),
            image_route=image_identity,
            owned_encoder_at_load={"pid": 789 + offset, "creation_filetime_100ns": 890 + offset},
            encoder_backend_selection_at_load={"primary_backend": "CPU", "device_type": "CPU"},
        )
        plan["selected_native_module_audit_at_load"]["pid"] += offset
        plan["selected_native_module_audit_at_load"]["creation_filetime_100ns"] += offset
        runner.save(root / (phase + "-loaded-plan.json"), {"execution_plan": plan})
        runner.save(
            root / (phase + "-close.json"),
            {
                "exact_role_retirement": {"encoder": True, "language": True},
                "ledger_after_shutdown": receipt["ledger_final"],
            },
        )
        receipt[phase + "_loaded_plan_sha256"] = runner.canonical(plan)
        receipt[phase + "_route_controls_sha256"] = plan["route_controls_sha256"]
        receipt[phase + "_image_identity_sha256"] = image_identity["identity_sha256"]
        for index in range(1, 3 if phase == "initial" else 2):
            case_id, rid = "case_" + str(index), phase + "-request-" + str(index)
            stage = {"worker_generation": plan["worker_generation"], "epoch": index}
            sve = struct.pack("<5i", 0x31455653, 1, 1, 1, 4) + b"\0" * 16
            sve_sha = hashlib.sha256(sve).hexdigest()
            result = {"sve_bytes": len(sve), "sve_sha256": sve_sha}
            image = {"status": "complete", "native_encoder_request_seq": index, "encode_result": result}
            report = copy.deepcopy(native_report)
            report.update(
                request_id=rid,
                epoch=index,
                generation=plan["worker_generation"],
                native_request_seq=index,
                native_pid=plan["selected_native_module_audit_at_load"]["pid"],
                creation_filetime_100ns=plan["selected_native_module_audit_at_load"]["creation_filetime_100ns"],
            )
            proof = {
                "request_id": rid,
                "loaded_plan_sha256": runner.canonical(plan),
                "input": {"sha256": image_sha},
                "stage_event": stage,
                "image_observation": image,
                "native_io_observation": report,
                "physical_ssd_read_bytes": None,
                "release_qualified": False,
            }
            stem = phase + "-" + case_id
            runner.save(root / (stem + "-proof.json"), proof)
            runner.save(
                root / (stem + ".json"),
                {
                    "status": "completed",
                    "quality": {"passed": True},
                    "finish_reason": "stop",
                    "request_id": rid,
                    "stage_events": [stage],
                    "metrics": {"runtime_telemetry": {"image_observation": image, "native_io_observation": report}},
                },
            )
            (root / (stem + ".sve")).write_bytes(sve)
            receipt["requests"].append(
                {
                    "phase": phase,
                    "case_id": case_id,
                    "request_id": rid,
                    "native_seq": index,
                    "encoder_seq": index,
                    "quality_passed": True,
                    "finish_reason": "stop",
                    "proof_file": stem + "-proof.json",
                    "proof_sha256": runner.canonical(proof),
                    "sve_sha256": sve_sha,
                }
            )
    plan = plans["initial"]
    window = {
        "request_id": "encoder-cancel",
        "epoch": 3,
        "generation": plan["worker_generation"],
        "owned_encoder": plan["owned_encoder_at_load"],
        "backend_selection": plan["encoder_backend_selection_at_load"],
        "native_encoder_request_seq": 3,
        "input_sha256": image_sha,
        "encode_start": {"image_sha256": image_sha},
        "encode_end": None,
        "language_dispatch": None,
        "observed_monotonic_s": 1,
    }
    cancelled = {
        "status": "cancelled_during_observed_encoder_phase",
        "exact_role_retirement": {"encoder": True, "language": True},
        "cancel": {"drained": True},
        "window": window,
        "cancel_call_started_monotonic_s": 2,
        "cancel_call_finished_monotonic_s": 3,
        "image_observation": {
            "status": "incomplete",
            "request_id": window["request_id"],
            "epoch": window["epoch"],
            "generation": window["generation"],
            "owned_encoder": window["owned_encoder"],
            "native_encoder_request_seq": 3,
            "input_sha256": image_sha,
            "encode_result": None,
            "language_dispatch": None,
            "reasons": ["cancelled"],
            "physical_ssd_read_bytes": None,
            "release_qualified": False,
        },
        "native_io_observation": dict(
            native_report,
            status="incomplete",
            request_id=window["request_id"],
            epoch=window["epoch"],
            generation=window["generation"],
            native_request_seq=None,
            raw_snapshots=[],
            native_terminal=None,
        ),
    }
    runner.save(root / "encoder-cancellation.json", cancelled)
    runner.save(root / "after-cancel-loaded-plan.json", plan)
    runner.save(root / "after-cancel-ledger.json", receipt["ledger_final"])

    def finish():
        receipt["raw_files"] = {
            p.relative_to(root).as_posix(): {"size_bytes": p.stat().st_size, "sha256": runner.file_hash(p)}
            for p in root.rglob("*")
            if p.is_file() and p.name != "receipt.json"
        }
        runner.save(root / "receipt.json", receipt)
        return runner.file_hash(root / "receipt.json")

    def verify(expected=None):
        return runner.verify_completed_lifecycle(
            root / "receipt.json",
            launch,
            expected_receipt_sha256=expected or finish(),
            expected_runner_sha256=runner.file_hash(runner.__file__),
        )

    finish()
    return SimpleNamespace(root=root, receipt=receipt, plans=plans, finish=finish, verify=verify)


def test_completed_gate_checks_small_closed_synthetic_lifecycle_without_runtime_imports(closed_lifecycle, monkeypatch):
    monkeypatch.setattr(runner, "runtime_api", lambda: pytest.fail("prerequisite must remain stdlib-only"))
    assert closed_lifecycle.verify()["raw_closure_verified"] is True


@pytest.mark.parametrize(
    "mutation",
    [
        "receipt_pin",
        "source",
        "sampler",
        "ledger",
        "preimage",
        "extra",
        "changed",
        "scope",
        "cancel_race",
        "owner_unknown",
        "cancel_clock",
        "same_generation",
        "same_owner",
        "sve",
    ],
)
def test_completed_gate_rejects_tampered_or_incomplete_closure(closed_lifecycle, mutation):
    fixture = closed_lifecycle
    expected = None
    if mutation == "receipt_pin":
        expected = "0" * 64
    elif mutation == "source":
        fixture.receipt["source_after"] = {}
    elif mutation == "sampler":
        fixture.receipt["telemetry"]["sampling_thread_stopped"] = False
    elif mutation == "ledger":
        fixture.receipt["ledger_final"]["quarantined"] = [{}]
    elif mutation == "preimage":
        fixture.receipt["loaded_python_runtime_identity"]["changed"] = True
    elif mutation in {"extra", "changed"}:
        expected = fixture.finish()
        (fixture.root / ("extra.txt" if mutation == "extra" else "input.png")).write_bytes(b"changed")
    elif mutation == "scope":
        fixture.receipt["release_qualified"] = True
    elif mutation in {"cancel_race", "owner_unknown", "cancel_clock"}:
        path = fixture.root / "encoder-cancellation.json"
        value = runner.object_file(path)
        if mutation == "cancel_race":
            value["image_observation"]["encode_result"] = {"completed": True}
        elif mutation == "owner_unknown":
            value["exact_role_retirement"]["encoder"] = None
        else:
            value["cancel_call_started_monotonic_s"] = 0
        runner.save(path, value)
    elif mutation in {"same_generation", "same_owner"}:
        plan = fixture.plans["recovery"]
        key = "worker_generation" if mutation == "same_generation" else "owned_encoder_at_load"
        plan[key] = fixture.plans["initial"][key]
        runner.save(fixture.root / "recovery-loaded-plan.json", {"execution_plan": plan})
        fixture.receipt["recovery_loaded_plan_sha256"] = runner.canonical(plan)
    elif mutation == "sve":
        (fixture.root / "initial-case_1.sve").write_bytes(b"changed")
    if expected is None:
        expected = fixture.finish()
    with pytest.raises(ValueError):
        fixture.verify(expected)

@pytest.mark.parametrize('wrong_schema', [False, True])
def test_combined_native_io_requires_its_separate_schema(native, wrong_schema):
    report, plan = native
    plan['route_controls'] = {'execution_observation': {'declared': True}}
    if not wrong_schema:
        report['schema'] = 'omni-strata-combined-request-io-observation-v1'
        runner.validate_native(io, report, plan, 'request-a', 1, 1)
    else:
        with pytest.raises(ValueError):
            runner.validate_native(io, report, plan, 'request-a', 1, 1)