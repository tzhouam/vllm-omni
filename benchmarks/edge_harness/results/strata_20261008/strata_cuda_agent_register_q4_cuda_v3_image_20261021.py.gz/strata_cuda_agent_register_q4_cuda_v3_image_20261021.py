import hashlib,json,sys,traceback,time
from pathlib import Path
R=Path('C:/Users/zhout/w2/strata-omni')
repo=Path(r'\\wsl.localhost\Ubuntu\home\zhout\project\edge_infer\vllm-omni-edge')
sys.path.insert(0,str(repo))
from benchmarks.edge_harness.strata_vision_register import register_cuda_image_route
parent=R/'runs/q4-execution-cuda-v3-20261021'
out=R/'runs/q4-image-cuda-v3-6g-20261021'
raw=(parent/'launch.json').read_bytes()
attempt=json.loads((parent/'registration-attempt.json').read_bytes())
if attempt['status']!='registered_not_executed' or hashlib.sha256(raw).hexdigest()!=attempt['launch_sha256']:raise ValueError('successful unchanged text registration required')
if out.exists():raise RuntimeError('fresh output required')
out.mkdir()
import threading,time,psutil
profile_stop=threading.Event()
profile_path=R/'prototypes/cuda-v3-image-registration-resources-20261021.jsonl'
def profile():
    process=psutil.Process()
    with profile_path.open('x',encoding='utf-8') as stream:
        stream.write(json.dumps({'scope':'registration process tree; logical IO is not physical SSD IO','pid':process.pid,'created':process.create_time()})+'\n')
        while not profile_stop.is_set():
            rows=[]
            for item in [process,*process.children(recursive=True)]:
                try:
                    rows.append(dict(pid=item.pid,created=item.create_time(),memory=item.memory_info()._asdict(),cpu=item.cpu_times()._asdict(),io=item.io_counters()._asdict()))
                except psutil.Error: pass
            stream.write(json.dumps({'time':time.time(),'processes':rows,'system_available_ram':psutil.virtual_memory().available})+'\n');stream.flush()
            profile_stop.wait(1)
profile_thread=threading.Thread(target=profile,daemon=True);profile_thread.start()

receipt=dict(status='running',model_executed=False,started_unix=time.time(),text_launch_sha256=attempt['launch_sha256'],script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
try:
    result=register_cuda_image_route(parent/'launch.json',text_registration_path=parent/'launch.registration.json',image_route=json.loads((R/'prototypes/q4-cuda-v3-image-route-20261021.json').read_bytes()),launch_out=out/'launch.json',route_id='unsloth-q4-6g-cuda-v3-image-experimental',max_io_bytes=8<<20,execution_source_context_file='adapter/image-source-context.json',expert_ram_budget_bytes=6<<30)
    receipt.update(status=result['status'],launch_sha256=hashlib.sha256((out/'launch.json').read_bytes()).hexdigest())
except BaseException:
    receipt.update(status='failed',traceback=traceback.format_exc());raise
finally:
    receipt['finished_unix']=time.time()
    (out/'attempt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    profile_stop.set();profile_thread.join(timeout=5)
print(json.dumps(receipt),flush=True)