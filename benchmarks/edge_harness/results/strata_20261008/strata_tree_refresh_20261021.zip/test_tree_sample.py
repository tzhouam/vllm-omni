import math
import unittest

from tree_sample import ProcessTreeSample


class Clock:
    value = 0.0

    def monotonic(self):
        return self.value

    def wall(self):
        return 1000 + self.value


class SamplingTests(unittest.TestCase):
    def make(self, collect, **kwargs):
        self.clock = Clock()
        return ProcessTreeSample(
            collect, monotonic=self.clock.monotonic, wall=self.clock.wall, **kwargs
        )

    def test_cached_value_has_age_and_refresh_reobserves_changed_tree(self):
        observed = []

        def collect():
            observed.append(True)
            return len(observed) * 10

        sampler = self.make(collect)
        first = sampler.sample()
        self.clock.value = 0.5
        cached = sampler.sample()
        self.assertEqual(len(observed), 1)
        self.assertEqual(cached["process_tree_rss_sum_bytes"], 10)
        self.assertEqual(cached["process_tree_sample_age_s"], 0.5)
        self.assertFalse(cached["process_tree_refreshed"])
        first["process_tree_rss_sum_bytes"] = 999
        self.assertEqual(sampler.sample()["process_tree_rss_sum_bytes"], 10)
        self.clock.value = 1.0
        self.assertEqual(sampler.sample()["process_tree_rss_sum_bytes"], 20)
        self.assertEqual(len(observed), 2)

    def test_failed_refresh_does_not_relabel_old_success_as_current(self):
        def collect():
            if self.clock.value:
                raise PermissionError()
            return 42

        sampler = self.make(collect)
        sampler.sample()
        self.clock.value = 1.0
        failed = sampler.sample()
        self.assertIsNone(failed["process_tree_rss_sum_bytes"])
        self.assertEqual(failed["process_tree_error"], "PermissionError")
        self.clock.value = 1.1
        self.assertFalse(sampler.sample()["process_tree_refreshed"])

    def test_collection_time_counts_toward_age_and_schedules_after_completion(self):
        def collect():
            self.clock.value += 0.6
            return 1

        sampler = self.make(collect)
        row = sampler.sample()
        self.assertEqual(row["process_tree_collection_s"], 0.6)
        self.assertEqual(row["process_tree_sample_age_s"], 0.6)
        self.clock.value = 1.0
        self.assertFalse(sampler.sample()["process_tree_refreshed"])
        self.clock.value = 1.6
        self.assertTrue(sampler.sample()["process_tree_refreshed"])

    def test_zero_is_valid_and_not_a_missing_observation(self):
        row = self.make(lambda: 0).sample()
        self.assertEqual(row["process_tree_rss_sum_bytes"], 0)
        self.assertIsNone(row["process_tree_error"])

    def test_invalid_values_are_unknown(self):
        for value in (-1, True, math.nan, None):
            row = self.make(lambda: value).sample()
            self.assertIsNone(row["process_tree_rss_sum_bytes"])
            self.assertEqual(row["process_tree_error"], "ValueError")

    def test_invalid_refresh_interval(self):
        for interval in (0, -1, True, math.inf, math.nan):
            with self.assertRaises(ValueError):
                self.make(lambda: 1, interval_s=interval)


if __name__ == "__main__":
    unittest.main()
