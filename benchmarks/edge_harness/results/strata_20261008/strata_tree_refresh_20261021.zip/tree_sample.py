"""Private telemetry prototype; not imported by the running engine."""
import math
import time


class ProcessTreeSample:
    """Cache whole tree RSS observations, with explicit age and collection cost."""

    def __init__(self, collect, interval_s=1.0, *, monotonic=time.monotonic, wall=time.time):
        if isinstance(interval_s, bool) or not math.isfinite(interval_s) or interval_s <= 0:
            raise ValueError("refresh interval must be finite and positive")
        self.collect = collect
        self.interval_s = interval_s
        self.monotonic = monotonic
        self.wall = wall
        self.next_due = None
        self.observation = None
        self.started = None

    def sample(self):
        refreshed = self.next_due is None or self.monotonic() >= self.next_due
        if refreshed:
            self.started = self.monotonic()
            started_unix = self.wall()
            value, error = None, None
            try:
                value = self.collect()
                if type(value) is not int or value < 0:
                    raise ValueError("RSS sum must be a nonnegative integer")
            except Exception as exc:
                value, error = None, type(exc).__name__
            completed = self.monotonic()
            # Schedule after completion: a slow observation must not spin.
            self.next_due = completed + self.interval_s
            self.observation = {
                "process_tree_rss_sum_bytes": value,
                "process_tree_sample_started_unix": started_unix,
                "process_tree_collection_s": completed - self.started,
                "process_tree_error": error,
            }
        return {
            **self.observation,
            "process_tree_sample_age_s": max(0.0, self.monotonic() - self.started),
            "process_tree_refresh_interval_s": self.interval_s,
            "process_tree_refreshed": refreshed,
            "process_tree_scope": "sampled RSS sum; shared pages may be counted multiple times",
        }
