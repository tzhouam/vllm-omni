"""Bounded, model-free observer cost experiment; no Agent latency claim."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import psutil

from tree_sample import ProcessTreeSample


def main():
    folder = Path(__file__).parent
    target = folder / "cost-results.json"
    if target.exists():
        raise FileExistsError(target)
    if any(p.info["name"].lower() in {"strata.exe", "strata-vision.exe"}
           for p in psutil.process_iter(["name"])):
        raise RuntimeError("Model processes must be absent")
    children, runs = [], []
    try:
        for _ in range(3):
            children.append(subprocess.Popen(
                [sys.executable, "-I", "-B", "-c", "import time; time.sleep(60)"],
                creationflags=subprocess.CREATE_NO_WINDOW,
            ))
        for mode in ("baseline", "cached", "cached", "baseline", "baseline", "cached"):
            if any(p.poll() is not None for p in children):
                raise RuntimeError("Controlled child tree exited early")
            collections = []

            def collect():
                began = time.perf_counter()
                root = psutil.Process()
                tree = [root] + root.children(recursive=True)
                value = sum(p.memory_info().rss for p in tree if p.is_running())
                collections.append(dict(
                    elapsed_s=time.perf_counter() - began, processes=len(tree), rss_sum_bytes=value
                ))
                return value

            sampler = ProcessTreeSample(collect, interval_s=1.0)
            began, cpu = time.perf_counter(), time.process_time()
            polls, max_age = 0, 0.0
            while time.perf_counter() - began < 4.0:
                if mode == "baseline":
                    collect()
                else:
                    row = sampler.sample()
                    if row["process_tree_error"] is not None:
                        raise RuntimeError(row["process_tree_error"])
                    max_age = max(max_age, row["process_tree_sample_age_s"])
                polls += 1
                time.sleep(0.1)
            runs.append(dict(
                mode=mode, wall_s=time.perf_counter() - began, cpu_s=time.process_time() - cpu,
                polls=polls, collections=collections, max_returned_sample_age_s=max_age,
            ))
    finally:
        for p in children:
            if p.poll() is None:
                p.terminate()
            p.wait(timeout=5)
    report = dict(
        schema="omni-process-tree-refresh-cost-v1", runs=runs, psutil=psutil.__version__,
        controlled_children=3, children_retired=all(p.poll() is not None for p in children),
        source_sha256={name: hashlib.sha256((folder / name).read_bytes()).hexdigest()
                       for name in ("tree_sample.py", "benchmark_tree.py")},
        limits=[
            "Observer microbenchmark only; no neural model or Agent request",
            "Baseline calls existing psutil tree/RSS operation every loop with 100 ms sleep",
            "Candidate refreshes whole tree RSS at one-second intervals after completion",
            "Cached values are older, with explicit timestamps and age; not 10 Hz tree peak measurement",
            "Three alternating repetitions per mode; host background activity is uncontrolled",
            "Small idle child tree does not represent every application topology",
        ],
    )
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps([dict(mode=r["mode"], wall_s=r["wall_s"], cpu_s=r["cpu_s"],
                           collections=len(r["collections"]), polls=r["polls"]) for r in runs]))


if __name__ == "__main__":
    main()
