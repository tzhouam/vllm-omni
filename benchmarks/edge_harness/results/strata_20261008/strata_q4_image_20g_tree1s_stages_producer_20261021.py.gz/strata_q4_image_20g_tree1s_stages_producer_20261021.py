import hashlib,json,math
from pathlib import Path
root=Path(r'C:\Users\zhout\w2\strata-omni');run=root/'runs/q4-image-agent-full-20g-tree1s-20261021'
rbytes=(run/'receipt.json').read_bytes();r=json.loads(rbytes)
assert hashlib.sha256(rbytes).hexdigest()=='f4d863fd76033fd36bdb06bd7325dbb2fad1163c9310dd6e86db9eaa4ace30f7'
b=(run/'all-raw.json').read_bytes();assert hashlib.sha256(b).hexdigest()==r['raw_files']['all-raw.json']['sha256']
raw=json.loads(b); bands={}
for band in ('short','medium','long'):
 rows=[]
 for sample in r['samples']:
  if sample['phase']!='measured' or sample['length']!=band:continue
  calls=raw['calls'][sample['call_start']:sample['call_end']];assert len(calls)==2
  row={'index':sample['index'],'whole_task_s':sample['whole_agent_task_s_excludes_load'],'calls':[]}
  for c in calls:
   m=c['terminal_metrics']['backend_metrics'];t=m['runtime_timings'];im=m['runtime_telemetry']['image_observation']
   row['calls'].append({'wall_s':c['wall_s'],'prompt_s':t['prompt_ms']/1000,'decode_s':t['predicted_ms']/1000,'prompt_tokens':t['prompt_n'],'output_tokens':t['predicted_n'],'encoder_s':im['encode_result']['native_encoder_ms']/1000 if im else None})
  rows.append(row)
 assert len(rows)==20
 summary={}
 for step in (0,1):
  summary[str(step)]={}
  for key in ('wall_s','prompt_s','decode_s','encoder_s'):
   vals=[x['calls'][step][key] for x in rows if x['calls'][step][key] is not None]
   if vals:
    assert all(math.isfinite(x) and x>=0 for x in vals)
    v=sorted(vals);summary[str(step)][key]={'n':len(vals),'p50':v[math.ceil(len(v)*.5)-1],'p95':v[math.ceil(len(v)*.95)-1]}
 bands[band]={'samples':rows,'summary':summary}
out={'schema':'omni-strata-20g-tree1s-stage-analysis-v1','receipt_sha256':hashlib.sha256(rbytes).hexdigest(),'all_raw_sha256':hashlib.sha256(b).hexdigest(),'batch_size':1,'concurrency':1,'method':'nearest_rank; measured requests only','bands':bands,'limitations':['Runtime prompt/decode and encoder intervals are nested inside call wall time; do not add quantiles or treat them as independent stages.','Single configuration; no causal comparison or speedup claim.','CPU encoder selected; whole-model execution attribution and physical SSD time remain unqualified.','Fixed screenshot task family; not broad Agent task quality.']}
p=root/'runs/q4-image-agent-full-20g-tree1s-stage-analysis-20261021.json'
with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:v['summary'] for k,v in bands.items()}))