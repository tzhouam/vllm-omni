
#include <chrono>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
struct mtmd_bitmap {};
struct mtmd_input_chunks {};
struct mtmd_input_chunk { size_t tokens; int type; };
struct mtmd_input_text {const char * text;size_t length;bool a,b;};
constexpr int MTMD_INPUT_CHUNK_TYPE_IMAGE=1;
struct Scenario {bool bitmap=true,chunks=true;int tokenize=0,encode=0;std::vector<mtmd_input_chunk> items={{10,1}};} cfg;
mtmd_bitmap bitmap;mtmd_input_chunks chunks_obj;
int frees=0,encodes=0,ready=0,model_frees=0,backend_frees=0,bitmap_frees=0,chunk_frees=0;
mtmd_bitmap* mtmd_bitmap_init(uint32_t,uint32_t,const unsigned char*) {return cfg.bitmap?&bitmap:nullptr;}
mtmd_input_chunks* mtmd_input_chunks_init(){return cfg.chunks?&chunks_obj:nullptr;}
std::string mtmd_default_marker(){return "image";}
int mtmd_tokenize(void*,mtmd_input_chunks*,mtmd_input_text*,const mtmd_bitmap**,int){return cfg.tokenize;}
size_t mtmd_input_chunks_size(mtmd_input_chunks*){return cfg.items.size();}
const mtmd_input_chunk* mtmd_input_chunks_get(mtmd_input_chunks*,size_t i){return &cfg.items.at(i);}
int mtmd_input_chunk_get_type(const mtmd_input_chunk* p){return p->type;}
size_t mtmd_input_chunk_get_n_tokens(const mtmd_input_chunk* p){return p->tokens;}
int mtmd_encode_chunk(void*,const mtmd_input_chunk*){++encodes;return cfg.encode;}
void mtmd_input_chunks_free(mtmd_input_chunks*){++chunk_frees;}
void mtmd_bitmap_free(mtmd_bitmap*){++bitmap_frees;}
void mtmd_free(void*){++frees;}
void llama_model_free(void*){++model_frees;}
void llama_backend_free(){++backend_frees;}
int run(){void* ctx=nullptr;void* text=nullptr;int max_tokens=1536;
        const auto warm_t0 = std::chrono::steady_clock::now();
        const uint32_t side = 2048;
        std::vector<unsigned char> rgb((size_t) side * side * 3, 128);
        mtmd_bitmap* bm = mtmd_bitmap_init(side, side, rgb.data());
        mtmd_input_chunks* chunks = mtmd_input_chunks_init();
        const std::string marker = mtmd_default_marker();
        mtmd_input_text txt{marker.c_str(), marker.size(), false, true};
        const mtmd_bitmap* bms[1] = {bm};
        int warm_tokens = 0;
        int warm_images = 0;
        bool warm_ok = bm && chunks && mtmd_tokenize(ctx, chunks, &txt, bms, 1) == 0;
        if (warm_ok) {
            for (size_t c = 0; c < mtmd_input_chunks_size(chunks); ++c) {
                const mtmd_input_chunk* ch = mtmd_input_chunks_get(chunks, c);
                if (mtmd_input_chunk_get_type(ch) != MTMD_INPUT_CHUNK_TYPE_IMAGE) continue;
                ++warm_images;
                const auto tokens = mtmd_input_chunk_get_n_tokens(ch);
                if (tokens == 0 || (max_tokens > 0 && tokens > (size_t) max_tokens) ||
                    mtmd_encode_chunk(ctx, ch) != 0) {
                    warm_ok = false;
                    break;
                }
                warm_tokens = (int) tokens;
            }
        }
        warm_ok = warm_ok && warm_images == 1 && warm_tokens > 0;
        std::fprintf(stderr, "strata-vision: warmed up at %d image tokens in %.1f s\n", warm_tokens,
                     std::chrono::duration<double>(std::chrono::steady_clock::now() - warm_t0).count());
        if (chunks) mtmd_input_chunks_free(chunks);
        if (bm) mtmd_bitmap_free(bm);
        if (!warm_ok) {
            std::printf("ERR GPU warmup failed or violated the image token bound\n");
            std::fflush(stdout);
            mtmd_free(ctx);
            llama_model_free(text);
            llama_backend_free();
            return 1;
        }
        std::printf("OMNI_VISION_WARMUP_V1 {\"schema\":\"strata-vision-warmup-v1\","
                    "\"pixels\":%u,\"image_tokens\":%d,\"max_image_tokens\":%d,"
                    "\"elapsed_ms\":%.3f,\"status\":\"passed\"}\n",
                    side * side, warm_tokens, max_tokens,
                    std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - warm_t0).count());
        std::fflush(stdout);
++ready;return 0;}
void check(const char* name,bool success,int expected_encodes){
 frees=encodes=ready=model_frees=backend_frees=bitmap_frees=chunk_frees=0;
 int result=run();
 bool ok=result==(success?0:1)&&ready==(success?1:0)&&frees==(success?0:1)&&model_frees==frees&&backend_frees==frees&&encodes==expected_encodes&&bitmap_frees==(cfg.bitmap?1:0)&&chunk_frees==(cfg.chunks?1:0);
 if(!ok){std::fprintf(stderr,"FAIL %s result=%d ready=%d frees=%d encodes=%d\n",name,result,ready,frees,encodes);std::exit(2);}
 std::printf("TEST PASS %s\n",name);
}
int main(){
 cfg=Scenario{};check("valid",true,1);
 cfg=Scenario{};cfg.bitmap=false;check("bitmap allocation failure",false,0);
 cfg=Scenario{};cfg.chunks=false;check("chunks allocation failure",false,0);
 cfg=Scenario{};cfg.tokenize=1;check("tokenize failure",false,0);
 cfg=Scenario{};cfg.encode=1;check("encode failure",false,1);
 cfg=Scenario{};cfg.items={{0,1}};check("zero tokens",false,0);
 cfg=Scenario{};cfg.items={{1537,1}};check("over token bound",false,0);
 cfg=Scenario{};cfg.items={{1536,1}};check("exact token bound",true,1);
 cfg=Scenario{};cfg.items={};check("missing image",false,0);
 cfg=Scenario{};cfg.items={{10,1},{10,1}};check("multiple images",false,2);
 cfg=Scenario{};cfg.items={{0,0},{10,1}};check("text plus image",true,1);
 return 0;
}
