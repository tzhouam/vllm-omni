import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import unittest
from unittest import mock

source = Path(sys.argv[1]).resolve(strict=True)
output = Path(__file__).parent
sys.path.insert(0, str(source))
from serve import server, test_ready_timeout, test_vision_busy, test_request_accounting

class DirectWindowsReadyTimeout(test_ready_timeout.ReadyTimeout):
    __unittest_skip__ = False
    __unittest_skip_why__ = ''

    def setUp(self):
        super().setUp()
        self.scripts = {}
        original = server.popen
        def direct(title, argv, *args, **kwargs):
            argv = list(argv)
            if argv[0] in self.scripts:
                argv = [sys.executable, '-I', '-B', '-u', str(self.scripts[argv[0]]), *argv[1:]]
            return original(title, argv, *args, **kwargs)
        patcher = mock.patch.object(server, 'popen', direct)
        patcher.start()
        self.addCleanup(patcher.stop)

    def make_script(self, name, code):
        script = self.root / (name + '.py')
        script.write_text(code, encoding='utf-8')
        key = str(self.root / (name + '.direct-test-engine'))
        self.scripts[key] = script
        return key

suite = unittest.TestSuite([
    unittest.defaultTestLoader.loadTestsFromTestCase(DirectWindowsReadyTimeout),
    unittest.defaultTestLoader.loadTestsFromModule(test_vision_busy),
    unittest.defaultTestLoader.loadTestsFromModule(test_request_accounting),
])
# Hash the actual imported upstream modules before and after this offline run.
files = {str(Path(m.__file__).resolve()) for m in tuple(sys.modules.values())
         if getattr(m, '__file__', None) and Path(m.__file__).resolve().is_relative_to(source)}
def hashes():
    return {str(Path(p).relative_to(source)): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(files)}
before = hashes()
with (output/'tests.log').open('x', encoding='utf-8') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
stable = before == hashes()
receipt = dict(tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
               skipped=len(result.skipped), success=result.wasSuccessful() and stable,
               source_files=before, source_stable=stable, model_loaded=False,
               harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               log_sha256=hashlib.sha256((output/'tests.log').read_bytes()).hexdigest(),
               python_version=sys.version, os=os.name,
               scope='Upstream service tests; fake engine protocol and mocked vision; no Omni/bootstrap or neural qualification',
               adaptation='Windows timeout tests directly spawn isolated Python scripts, avoiding the skipped CMD wrapper and its surviving child')
(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='source_files'}))
raise SystemExit(not receipt['success'])
