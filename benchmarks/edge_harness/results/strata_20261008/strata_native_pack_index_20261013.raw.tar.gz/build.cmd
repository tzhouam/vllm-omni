@echo off
setlocal
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /std:c++17 /EHsc /MT /I"C:\Users\zhout\w2\strata-omni\source-upstream-review-20261013\include" probe.cpp /Fe:probe.exe /link "C:\Users\zhout\w2\strata-omni\build-upstream-01431-port-v1\strata_core.lib" "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.4\lib\x64\cudart_static.lib" kernel32.lib user32.lib advapi32.lib
exit /b %errorlevel%
