#include "strata/core/weights.hpp"
#include <iostream>
#include <string>
int main(int argc, char** argv) {
    if (argc != 3) return 2;
    std::string err;
    uint64_t bytes = 0;
    if (!strata::core::WeightTable::pool_bytes(argv[1], bytes, err) || !bytes) return 3;
    strata::core::WeightTable table;
    bool loaded = table.load(argv[1], nullptr, 0, err);
    std::string expected = "arena is 0 B but the index needs " + std::to_string(bytes);
    std::cout << "pool_bytes=" << bytes << "\nvalid_result=" << err << "\n";
    if (loaded || err != expected) return 4;
    err.clear();
    loaded = table.load(argv[2], nullptr, 0, err);
    std::cout << "invalid_result=" << err << "\n";
    if (loaded || err.find("index.txt: could not parse a row") != 0) return 5;
    return 0;
}
